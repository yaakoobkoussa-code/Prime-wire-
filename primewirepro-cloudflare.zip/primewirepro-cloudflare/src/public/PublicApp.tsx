import React, { useState } from 'react';
import { ErrorBoundary } from '../components/common/ErrorBoundary';
import { LoadingScreen } from '../components/common/LoadingScreen';
import { ToastProvider } from '../shared/ToastProvider';
import { PublicAccountPage } from './components/PublicAccountPage';
import { PublicFeaturesPage } from './components/PublicFeaturesPage';
import { PublicHomeDashboard } from './components/PublicHomeDashboard';
import { PublicLoginPage } from './components/PublicLoginPage';
import { PublicShell, PublicTab } from './components/PublicShell';
import { PublicServerSelection } from './components/PublicServerSelection';
import { MaintenancePage } from './components/MaintenancePage';
import { PublicAuthProvider, usePublicAuth } from './hooks/usePublicAuth';

const PublicRouter: React.FC = () => {
  const { booting, publicStatus, userData, refreshUser } = usePublicAuth();
  const [tab, setTab] = useState<PublicTab>('home');
  const [showServers, setShowServers] = useState(false);

  if (booting) {
    return <LoadingScreen message="Connecting to PRIME WIRE PRO" />;
  }

  if (publicStatus?.maintenanceMode) {
    return (
      <MaintenancePage
        title={publicStatus.websiteTitle}
        message={publicStatus.maintenanceMessage}
        onRetry={refreshUser}
      />
    );
  }

  if (!userData) {
    return <PublicLoginPage />;
  }

  const handleSelectTab = (next: PublicTab) => {
    setShowServers(false);
    setTab(next);
  };

  return (
    <PublicShell activeTab={tab} onSelectTab={handleSelectTab}>
      {showServers ? (
        <PublicServerSelection onBack={() => setShowServers(false)} />
      ) : tab === 'home' ? (
        <PublicHomeDashboard onOpenServers={() => setShowServers(true)} />
      ) : tab === 'features' ? (
        <PublicFeaturesPage />
      ) : (
        <PublicAccountPage />
      )}
    </PublicShell>
  );
};

export const PublicApp: React.FC = () => {
  return (
    <ErrorBoundary>
      <ToastProvider>
        <PublicAuthProvider>
          <PublicRouter />
        </PublicAuthProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
};
