import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  Copy,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  LogOut,
  Smartphone,
  UserCheck,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useToast } from '../../shared/ToastProvider';
import {
  formatDateShort,
  formatDateTime,
  maskProductKey,
} from '../../utils/formatters';
import { usePublicAuth } from '../hooks/usePublicAuth';

export const PublicAccountPage: React.FC = () => {
  const { userData, logout } = usePublicAuth();
  const { addToast } = useToast();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [revealKey, setRevealKey] = useState(false);
  const [iosGuideOpen, setIosGuideOpen] = useState(false);

  if (!userData) return null;
  const { session, credential, device, servers } = userData;
  const selectedServer = servers.find((s) => s.id === session.selectedServerId);

  const copyKey = async () => {
    try {
      await navigator.clipboard.writeText(credential.code);
      addToast({ type: 'success', title: 'Code copied to clipboard' });
    } catch {
      addToast({ type: 'info', title: 'Clipboard unavailable' });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Account
        </h1>
        <p className="mt-1 text-sm text-zinc-400">
          Subscription status, credential details, and registered device binding.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section className="rounded-2xl bg-[#111116] border border-white/8 p-5 sm:p-6 space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-white">
                  Account & Subscription
                </h2>
                <p className="text-xs text-zinc-400">
                  {session.authType === 'product_key' ? 'Individual License' : 'Universal Public Code'}
                </p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span className="capitalize">{credential.status}</span>
            </span>
          </div>

          <div className="divide-y divide-white/8 text-sm">
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Subscription Status</span>
              <span className="font-medium text-emerald-400 capitalize">{credential.status}</span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Activation Date</span>
              <span className="font-medium text-zinc-200 tabular-nums">
                {formatDateShort(credential.activatedAt)}
              </span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Expiration Date</span>
              <span className="font-medium text-zinc-200 tabular-nums">
                {formatDateShort(credential.expiresAt)}
              </span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Selected Server</span>
              <span className="font-medium text-zinc-200">
                {selectedServer ? `${selectedServer.flag} ${selectedServer.name}` : '—'}
              </span>
            </div>
          </div>
        </section>

        <section className="rounded-2xl bg-[#111116] border border-white/8 p-5 sm:p-6 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Access Code & Device Binding
              </h2>
              <p className="text-xs text-zinc-400">
                {device.permanentBinding
                  ? 'Permanently bound to this registered device'
                  : 'Multi-user shared code (no device lock)'}
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-[#080808] border border-white/8 px-3.5 py-2.5 flex items-center justify-between gap-2">
            <code className="font-mono text-sm text-zinc-100 tracking-wider truncate">
              {revealKey
                ? credential.code
                : session.authType === 'product_key'
                ? maskProductKey(credential.code)
                : `${credential.code.slice(0, 3)}••••`}
            </code>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => setRevealKey((v) => !v)}
                aria-label={revealKey ? 'Hide key' : 'Reveal key'}
                className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-white/8 text-zinc-400 hover:text-white flex items-center justify-center transition-colors"
              >
                {revealKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={copyKey}
                aria-label="Copy key"
                className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-purple-500/15 text-zinc-400 hover:text-purple-300 flex items-center justify-center transition-colors"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="divide-y divide-white/8 text-sm">
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-zinc-500" />
                <span>Registered Device</span>
              </span>
              <span className="font-medium text-white">{device.label}</span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Platform</span>
              <span className="font-medium text-zinc-200">{device.platform}</span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Device ID</span>
              <span className="font-mono text-xs text-zinc-300">{device.id}</span>
            </div>
            <div className="py-3 flex items-center justify-between gap-4">
              <span className="text-zinc-400">Session Started</span>
              <span className="font-medium text-zinc-200 tabular-nums">
                {formatDateTime(session.signedInAt)}
              </span>
            </div>
          </div>
        </section>
      </div>

      <div className="rounded-2xl bg-[#111116] border border-white/8 p-5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-base font-semibold text-white">Session Controls</h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            {device.permanentBinding
              ? 'Signing out closes your session. Permanent device binding remains active until an administrator unbinds it.'
              : 'Install PRIME WIRE PRO or sign out of your current session.'}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {!isInstalled && isInstallable && (
            <button
              type="button"
              onClick={install}
              className="min-h-[44px] px-4 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-sm font-medium text-purple-200 flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Install App</span>
            </button>
          )}
          {!isInstalled && !isInstallable && isIOS && (
            <button
              type="button"
              onClick={() => setIosGuideOpen(true)}
              className="min-h-[44px] px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-medium text-zinc-200 flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4 text-purple-400" />
              <span>Install on iOS</span>
            </button>
          )}
          <button
            type="button"
            onClick={logout}
            className="min-h-[44px] px-5 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 border border-rose-500/35 text-sm font-semibold text-rose-300 flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      <Modal
        open={iosGuideOpen}
        onClose={() => setIosGuideOpen(false)}
        title="Install on iPhone / iPad"
        subtitle="Add PRIME WIRE PRO to your iOS home screen"
      >
        <ol className="space-y-3 text-sm text-zinc-300 list-decimal list-inside">
          <li>Tap the Share button in Safari.</li>
          <li>Scroll down and tap &ldquo;Add to Home Screen&rdquo;.</li>
          <li>Tap &ldquo;Add&rdquo; to launch PRIME WIRE PRO in standalone mode.</li>
        </ol>
      </Modal>
    </motion.div>
  );
};
