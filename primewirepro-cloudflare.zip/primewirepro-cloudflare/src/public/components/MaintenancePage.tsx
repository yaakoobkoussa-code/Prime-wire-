import React from 'react';
import { RefreshCw, Wrench } from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';

interface MaintenancePageProps {
  title: string;
  message: string;
  onRetry: () => void;
}

export const MaintenancePage: React.FC<MaintenancePageProps> = ({
  title,
  message,
  onRetry,
}) => {
  return (
    <div className="min-h-screen bg-[#080808] text-zinc-100 flex flex-col items-center justify-center px-4 py-10 pt-safe pb-safe">
      <div className="w-full max-w-md rounded-2xl bg-[#101014] border border-purple-500/25 p-7 text-center shadow-2xl shadow-black/80">
        <div className="flex justify-center">
          <BrandLogo size="xl" glow />
        </div>
        <div className="mt-5 inline-flex items-center gap-2 text-xs font-medium text-amber-400">
          <Wrench className="w-4 h-4" />
          <span>Scheduled Maintenance</span>
        </div>
        <h1 className="mt-2 font-display text-2xl font-bold text-white">{title}</h1>
        <p className="mt-3 text-sm text-zinc-300 leading-relaxed">
          {message || 'System maintenance is currently in progress. Please check back shortly.'}
        </p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-6 w-full min-h-[46px] rounded-xl bg-purple-600 hover:bg-purple-500 text-sm font-semibold text-white inline-flex items-center justify-center gap-2 transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Check Availability</span>
        </button>
      </div>
    </div>
  );
};
