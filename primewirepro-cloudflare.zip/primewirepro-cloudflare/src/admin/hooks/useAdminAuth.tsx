import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  ApiError,
  apiRequest,
  getStoredAdminToken,
  setStoredAdminToken,
} from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { AdminUser } from '../../shared/types';

interface AdminAuthContextValue {
  booting: boolean;
  needsBootstrap: boolean;
  admin: AdminUser | null;
  can: (permission: string) => boolean;
  login: (identifier: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  bootstrapSuperAdmin: (input: {
    setupSecret: string;
    username: string;
    email: string;
    password: string;
  }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshAdmin: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextValue | null>(null);

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { addToast } = useToast();
  const [booting, setBooting] = useState(true);
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [admin, setAdmin] = useState<AdminUser | null>(null);

  const refreshAdmin = useCallback(async () => {
    try {
      const boot = await apiRequest<{ needsBootstrap: boolean }>('/api/admin/bootstrap-status');
      setNeedsBootstrap(boot.needsBootstrap);
      if (boot.needsBootstrap) {
        if (getStoredAdminToken()) {
          setStoredAdminToken(null);
        }
        setAdmin(null);
        return;
      }
    } catch {
      // Ignore transient bootstrap status check
    }

    try {
      const me = await apiRequest<{ admin: AdminUser }>('/api/admin/me', { scope: 'admin' });
      setAdmin(me.admin);
    } catch (err) {
      setAdmin(null);
      if (err instanceof ApiError && err.status === 401 && getStoredAdminToken()) {
        setStoredAdminToken(null);
      }
    }
  }, []);

  useEffect(() => {
    (async () => {
      await refreshAdmin();
      setBooting(false);
    })();
  }, [refreshAdmin]);

  const can = useCallback(
    (permission: string) => {
      if (!admin) return false;
      return admin.roleId === 'SUPER_ADMIN' || admin.permissions.includes(permission);
    },
    [admin]
  );

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        const res = await apiRequest<{
          ok: boolean;
          adminToken: string;
          admin: AdminUser;
        }>('/api/admin/login', {
          method: 'POST',
          body: { email: email.trim(), password },
        });
        setStoredAdminToken(res.adminToken);
        await refreshAdmin();
        addToast({ type: 'success', title: 'Administrator signed in' });
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof ApiError ? err.message : 'Unable to sign in.',
        };
      }
    },
    [refreshAdmin, addToast]
  );

  const bootstrapSuperAdmin = useCallback(
    async (input: {
      setupSecret: string;
      username: string;
      email: string;
      password: string;
    }) => {
      try {
        await apiRequest('/api/admin/bootstrap', {
          method: 'POST',
          body: input,
        });
        addToast({
          type: 'success',
          title: 'SUPER ADMIN created',
          description: 'Sign in using your new administrator credentials.',
        });
        await refreshAdmin();
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof ApiError ? err.message : 'Bootstrap failed.',
        };
      }
    },
    [refreshAdmin, addToast]
  );

  const logout = useCallback(async () => {
    try {
      await apiRequest('/api/admin/logout', { method: 'POST', scope: 'admin' });
    } catch {
      // Ignore error
    }
    setStoredAdminToken(null);
    setAdmin(null);
    addToast({ type: 'info', title: 'Signed out of admin console' });
  }, [addToast]);

  return (
    <AdminAuthContext.Provider
      value={{
        booting,
        needsBootstrap,
        admin,
        can,
        login,
        bootstrapSuperAdmin,
        logout,
        refreshAdmin,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
};

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used inside AdminAuthProvider');
  return ctx;
}
