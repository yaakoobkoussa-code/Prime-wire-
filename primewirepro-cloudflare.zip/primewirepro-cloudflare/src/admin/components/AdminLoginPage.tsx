import React, { useState } from 'react';
import { motion } from 'motion/react';
import { AlertCircle, Eye, EyeOff, Loader2, Lock, Mail, ShieldCheck } from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';
import { useAdminAuth } from '../hooks/useAdminAuth';

export const AdminLoginPage: React.FC = () => {
  const { needsBootstrap, login } = useAdminAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await login(email.trim(), password);
    setLoading(false);
    if (!res.ok && res.error) setError(res.error);
  };

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex flex-col justify-between px-4 py-6 pt-safe pb-safe">
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BrandLogo size="sm" glow={false} />
          <span className="font-display text-sm font-bold text-white">PRIME WIRE PRO</span>
        </div>
        <span className="text-xs font-mono text-zinc-500">Administration Dashboard</span>
      </div>

      <main className="w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-2xl bg-[#101015] border border-zinc-800 p-6 sm:p-8 shadow-2xl shadow-black/80"
        >
          <div className="flex items-center gap-3.5">
            <BrandLogo size="md" glow={false} />
            <div>
              <div className="flex items-center gap-1.5 text-xs font-medium text-purple-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Restricted Access</span>
              </div>
              <h1 className="font-display text-xl font-bold text-white">Admin Sign In</h1>
            </div>
          </div>

          <form onSubmit={handleLogin} className="mt-5 space-y-4">
            <p className="text-xs text-zinc-400 leading-relaxed">
              {needsBootstrap
                ? 'First-time setup: enter your Gmail/email and a strong password (min 8 characters) to create your SUPER ADMIN account and sign in.'
                : 'Sign in with your administrator Gmail/email and password.'}
            </p>

            <div>
              <label htmlFor="adm-email" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Email (Gmail)
              </label>
              <div className="relative flex items-center">
                <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="adm-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@gmail.com"
                  className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="adm-pw" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Password
              </label>
              <div className="relative flex items-center">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="adm-pw"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full min-h-[46px] pl-10 pr-11 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="min-w-[36px] min-h-[36px] absolute right-1.5 flex items-center justify-center rounded-lg text-zinc-400 hover:text-zinc-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div
                role="alert"
                className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-60 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <span>Sign In</span>
              )}
            </button>
          </form>
        </motion.div>
      </main>

      <footer className="w-full max-w-5xl mx-auto text-center text-xs text-zinc-600">
        PRIME WIRE PRO Administration · Cloudflare Workers & D1
      </footer>
    </div>
  );
};
