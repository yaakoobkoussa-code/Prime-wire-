import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  Ban,
  Clock,
  KeyRound,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import { apiRequest } from '../../shared/api';
import { formatDateShort, formatDateTime, maskProductKey } from '../../utils/formatters';
import { AdminSectionId } from './AdminShell';

interface OverviewData {
  stats: {
    totalKeys: number;
    activeKeys: number;
    expiredKeys: number;
    revokedKeys: number;
    suspendedKeys: number;
    totalUniversalCodes: number;
    activeUniversalCodes: number;
    registeredDevices: number;
    activeUserSessions: number;
  };
  recentKeys: {
    id: string;
    key_code: string;
    status: string;
    duration_seconds: number;
    bound_device_id: string | null;
    created_at: string;
    expires_at: string | null;
  }[];
  recentLogs: {
    id: string;
    event_type: string;
    timestamp: string;
    actor_label: string;
    result: string;
    details: string;
  }[];
  serverAccess: {
    id: string;
    name: string;
    flag: string;
    access_count: number;
  }[];
}

export const AdminOverviewPage: React.FC<{
  onNavigate: (section: AdminSectionId) => void;
}> = ({ onNavigate }) => {
  const [data, setData] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await apiRequest<OverviewData>('/api/admin/overview', { scope: 'admin' });
      setData(res);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load database metrics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading && !data) {
    return <p className="text-sm text-zinc-400">Loading database metrics...</p>;
  }
  if (!data) {
    return (
      <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-6 text-center space-y-3">
        <p className="text-sm text-rose-300">{loadError ?? 'Unable to load admin overview.'}</p>
        <button
          type="button"
          onClick={load}
          className="min-h-[40px] px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white"
        >
          Retry
        </button>
      </div>
    );
  }

  const cards = [
    { label: 'Total Keys', value: data.stats.totalKeys, icon: KeyRound, accent: 'text-purple-400' },
    { label: 'Active Keys', value: data.stats.activeKeys, icon: ShieldCheck, accent: 'text-emerald-400' },
    { label: 'Expired Keys', value: data.stats.expiredKeys, icon: Clock, accent: 'text-amber-400' },
    { label: 'Revoked / Suspended', value: data.stats.revokedKeys + data.stats.suspendedKeys, icon: Ban, accent: 'text-rose-400' },
    { label: 'Universal Codes', value: data.stats.totalUniversalCodes, icon: Sparkles, accent: 'text-purple-300' },
    { label: 'Active Universal', value: data.stats.activeUniversalCodes, icon: Activity, accent: 'text-emerald-400' },
    { label: 'Registered Devices', value: data.stats.registeredDevices, icon: Smartphone, accent: 'text-zinc-200' },
    { label: 'Active Sessions', value: data.stats.activeUserSessions, icon: Activity, accent: 'text-purple-400' },
  ];

  const maxAccess = Math.max(1, ...data.serverAccess.map((s) => s.access_count));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Admin Overview</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Live metrics from Cloudflare D1 across keys, universal codes, devices, and logs.
          </p>
        </div>
        <button
          type="button"
          onClick={load}
          className="self-start sm:self-auto min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-zinc-400 truncate">{c.label}</span>
                <Icon className={`w-4 h-4 shrink-0 ${c.accent}`} />
              </div>
              <p className="mt-3 font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">
                {c.value}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <section className="lg:col-span-5 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-white">
              Subscription Access by Region
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('servers')}
              className="text-xs text-purple-400 hover:text-purple-300"
            >
              Servers
            </button>
          </div>
          <div className="space-y-4">
            {data.serverAccess.map((s) => (
              <div key={s.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-200 font-medium">
                    {s.flag} {s.name}
                  </span>
                  <span className="font-mono text-zinc-400 tabular-nums">{s.access_count}</span>
                </div>
                <div className="h-2 rounded-full bg-zinc-900 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-purple-600"
                    style={{ width: `${Math.round((s.access_count / maxAccess) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="lg:col-span-7 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-white">Recent Product Keys</h2>
            <button
              type="button"
              onClick={() => onNavigate('keys')}
              className="text-xs text-purple-400 hover:text-purple-300"
            >
              View All
            </button>
          </div>

          {data.recentKeys.length === 0 ? (
            <p className="text-xs text-zinc-500 py-6 text-center">
              No product keys created yet. Generate keys in Key Management.
            </p>
          ) : (
            <div className="divide-y divide-zinc-800/70 text-xs">
              {data.recentKeys.map((k) => (
                <div key={k.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-mono text-zinc-100 truncate">{maskProductKey(k.key_code)}</p>
                    <p className="text-zinc-500 mt-0.5">
                      {k.bound_device_id ? 'Bound to device' : 'Unbound'} · Created{' '}
                      {formatDateShort(k.created_at)}
                    </p>
                  </div>
                  <span className="capitalize font-medium text-zinc-300 shrink-0">{k.status}</span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <section className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-base font-semibold text-white">Recent Security Events</h2>
          <button
            type="button"
            onClick={() => onNavigate('logs')}
            className="text-xs text-purple-400 hover:text-purple-300"
          >
            Full Audit Log
          </button>
        </div>

        {data.recentLogs.length === 0 ? (
          <p className="text-xs text-zinc-500 py-4 text-center">No audit events recorded yet.</p>
        ) : (
          <div className="divide-y divide-zinc-800/70 text-xs">
            {data.recentLogs.map((log) => (
              <div key={log.id} className="py-3 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-medium text-zinc-100">
                    {log.event_type} · <span className="text-zinc-400">{log.actor_label}</span>
                  </p>
                  {log.details && <p className="text-zinc-500 mt-0.5 truncate">{log.details}</p>}
                </div>
                <span className="font-mono text-zinc-500 tabular-nums shrink-0">
                  {formatDateTime(log.timestamp)}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
