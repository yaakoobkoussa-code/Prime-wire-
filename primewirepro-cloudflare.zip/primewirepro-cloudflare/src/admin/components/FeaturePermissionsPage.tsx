import React, { useCallback, useEffect, useState } from 'react';
import { RefreshCw, Save, ShieldCheck, Sliders } from 'lucide-react';
import { ToggleSwitch } from '../../components/common/ToggleSwitch';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { FeatureId } from '../../shared/types';
import { formatDateTime } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface FeatureRow {
  id: FeatureId;
  title: string;
  description: string;
  enabled: number;
  updated_at: string | null;
}

export const FeaturePermissionsPage: React.FC = () => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();
  const canManage = can('features.manage');

  const [features, setFeatures] = useState<FeatureRow[]>([]);
  const [descriptions, setDescriptions] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);

  const loadFeatures = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{ features: FeatureRow[] }>('/api/admin/features', {
        scope: 'admin',
      });
      setFeatures(res.features);
      const map: Record<string, string> = {};
      for (const f of res.features) {
        map[f.id] = f.description ?? '';
      }
      setDescriptions(map);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load features',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadFeatures();
  }, [loadFeatures]);

  const handleToggle = async (feat: FeatureRow) => {
    if (!canManage) return;
    setSavingId(feat.id);
    try {
      await apiRequest(`/api/admin/features/${feat.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: { enabled: feat.enabled !== 1 },
      });
      addToast({
        type: 'success',
        title: `${feat.title} ${feat.enabled === 1 ? 'disabled' : 'enabled'}`,
      });
      await loadFeatures();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to update feature',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setSavingId(null);
    }
  };

  const handleSaveDescription = async (feat: FeatureRow) => {
    if (!canManage) return;
    setSavingId(feat.id);
    try {
      await apiRequest(`/api/admin/features/${feat.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: { description: (descriptions[feat.id] ?? '').trim() },
      });
      addToast({ type: 'success', title: `${feat.title} description saved` });
      await loadFeatures();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to update description',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Feature Permissions</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Global availability controls for the 2 authorized PRIME WIRE PRO profiles.
          </p>
        </div>
        <button
          type="button"
          onClick={loadFeatures}
          className="self-start sm:self-auto min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {loading && features.length === 0 ? (
        <p className="text-sm text-zinc-400">Loading features...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {features.map((feat) => {
            const isEnabled = feat.enabled === 1;
            const isSaving = savingId === feat.id;
            return (
              <section
                key={feat.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center shrink-0">
                      <Sliders className="w-4 h-4 text-purple-400" />
                    </div>
                    <div className="min-w-0">
                      <h2 className="font-display text-base font-bold text-white truncate">
                        {feat.title}
                      </h2>
                      <p className="text-[11px] font-mono text-zinc-500 mt-0.5">{feat.id}</p>
                    </div>
                  </div>
                  <ToggleSwitch
                    checked={isEnabled}
                    disabled={!canManage || isSaving}
                    label={`Enable ${feat.title}`}
                    onChange={() => handleToggle(feat)}
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1.5">
                    User-Facing Description
                  </label>
                  <textarea
                    rows={3}
                    value={descriptions[feat.id] ?? ''}
                    disabled={!canManage}
                    onChange={(e) =>
                      setDescriptions((prev) => ({ ...prev, [feat.id]: e.target.value }))
                    }
                    className="w-full p-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-100 focus:outline-none focus:border-purple-500 disabled:opacity-60"
                  />
                </div>

                <div className="flex items-center justify-between gap-3 pt-2 border-t border-zinc-800/70">
                  <div className="text-xs text-zinc-400 flex items-center gap-1.5">
                    <ShieldCheck
                      className={`w-4 h-4 ${isEnabled ? 'text-emerald-400' : 'text-zinc-500'}`}
                    />
                    <span>
                      {isEnabled ? 'Globally active' : 'Globally disabled'}
                      {feat.updated_at ? ` · ${formatDateTime(feat.updated_at)}` : ''}
                    </span>
                  </div>

                  {canManage && (
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => handleSaveDescription(feat)}
                      className="min-h-[38px] px-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-semibold text-white inline-flex items-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSaving ? 'Saving...' : 'Save'}</span>
                    </button>
                  )}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
};
