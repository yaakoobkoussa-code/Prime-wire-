import React, { useCallback, useEffect, useState } from 'react';
import { PauseCircle, Plus, ShieldCheck, Trash2, UserCheck } from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { AdminRoleId } from '../../shared/types';
import { formatDateTime } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface AdminRow {
  id: string;
  username: string;
  email: string;
  role_id: AdminRoleId;
  custom_permissions_json: string;
  status: 'active' | 'suspended';
  created_at: string;
  last_login_at: string | null;
}

export const AdminManagementPage: React.FC = () => {
  const { admin: currentAdmin } = useAdminAuth();
  const { addToast } = useToast();

  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [roles, setRoles] = useState<{ id: AdminRoleId; name: string; description: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [roleId, setRoleId] = useState<AdminRoleId>('ADMIN');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{
        admins: AdminRow[];
        roles: { id: AdminRoleId; name: string; description: string }[];
      }>('/api/admin/admins', { scope: 'admin' });
      setAdmins(res.admins);
      setRoles(res.roles);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Access restricted',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/api/admin/admins', {
        method: 'POST',
        scope: 'admin',
        body: { username, email, password, roleId },
      });
      addToast({ type: 'success', title: 'Administrator created' });
      setCreateOpen(false);
      setUsername('');
      setEmail('');
      setPassword('');
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Create failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const updateAdmin = async (
    id: string,
    patch: { roleId?: AdminRoleId; status?: 'active' | 'suspended' }
  ) => {
    try {
      await apiRequest(`/api/admin/admins/${id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: patch,
      });
      addToast({ type: 'success', title: 'Administrator updated' });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Update failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const removeAdmin = async (id: string) => {
    try {
      await apiRequest(`/api/admin/admins/${id}`, {
        method: 'DELETE',
        scope: 'admin',
      });
      addToast({ type: 'info', title: 'Administrator removed' });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Administrator Management
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Only SUPER ADMIN accounts can create, promote, suspend, or delete administrators.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setCreateOpen(true)}
          className="self-start sm:self-auto min-h-[42px] px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white inline-flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Administrator</span>
        </button>
      </div>

      {loading ? (
        <p className="text-sm text-zinc-400">Loading administrators...</p>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {admins.map((a) => {
            const isSelf = a.id === currentAdmin?.id;
            return (
              <div
                key={a.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-display text-base font-semibold text-white truncate">
                        {a.username} {isSelf ? '(You)' : ''}
                      </p>
                      <p className="text-xs text-zinc-400 truncate">{a.email}</p>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-semibold capitalize ${
                      a.status === 'active' ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {a.status}
                  </span>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-zinc-400">
                  <span>
                    Last login:{' '}
                    {a.last_login_at ? formatDateTime(a.last_login_at) : 'Never'}
                  </span>
                  <select
                    aria-label={`Role for ${a.username}`}
                    disabled={isSelf}
                    value={a.role_id}
                    onChange={(e) =>
                      updateAdmin(a.id, { roleId: e.target.value as AdminRoleId })
                    }
                    className="min-h-[36px] px-2.5 rounded-lg bg-[#07070A] border border-zinc-800 text-xs font-mono text-purple-200 disabled:opacity-60"
                  >
                    {roles.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                </div>

                {!isSelf && (
                  <div className="flex items-center gap-2 pt-2 border-t border-zinc-800/70">
                    {a.status === 'active' ? (
                      <button
                        type="button"
                        onClick={() => updateAdmin(a.id, { status: 'suspended' })}
                        className="min-h-[36px] px-3 rounded-lg bg-amber-500/10 text-xs text-amber-300 inline-flex items-center gap-1.5"
                      >
                        <PauseCircle className="w-3.5 h-3.5" />
                        <span>Suspend</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => updateAdmin(a.id, { status: 'active' })}
                        className="min-h-[36px] px-3 rounded-lg bg-emerald-500/10 text-xs text-emerald-300 inline-flex items-center gap-1.5"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => removeAdmin(a.id)}
                      className="min-h-[36px] px-3 rounded-lg bg-rose-500/10 text-xs text-rose-300 ml-auto inline-flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Add Administrator"
        subtitle="Password is hashed with PBKDF2-SHA256 (100,000 iterations)"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label htmlFor="adm-new-user" className="block text-xs font-medium text-zinc-300 mb-1">
              Username
            </label>
            <input
              id="adm-new-user"
              required
              minLength={3}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="adm-new-email" className="block text-xs font-medium text-zinc-300 mb-1">
              Email
            </label>
            <input
              id="adm-new-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="adm-new-pw" className="block text-xs font-medium text-zinc-300 mb-1">
              Password (min 8 characters)
            </label>
            <input
              id="adm-new-pw"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="adm-new-role" className="block text-xs font-medium text-zinc-300 mb-1">
              Role
            </label>
            <select
              id="adm-new-role"
              value={roleId}
              onChange={(e) => setRoleId(e.target.value as AdminRoleId)}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            >
              {roles.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} — {r.description}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="min-h-[42px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[42px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white"
            >
              Create Admin
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
