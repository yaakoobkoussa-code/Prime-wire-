import React, { useState } from 'react';
import {
  BarChart3,
  Globe,
  KeyRound,
  Link2,
  LogOut,
  Menu,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';
import { useAdminAuth } from '../hooks/useAdminAuth';

export type AdminSectionId =
  | 'overview'
  | 'keys'
  | 'universal'
  | 'devices'
  | 'admins'
  | 'servers'
  | 'urls'
  | 'features'
  | 'settings'
  | 'logs';

interface AdminShellProps {
  activeSection: AdminSectionId;
  onSelectSection: (section: AdminSectionId) => void;
  children: React.ReactNode;
}

const NAV_ITEMS: {
  id: AdminSectionId;
  label: string;
  permission: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'overview', label: 'Admin Overview', permission: 'dashboard.view', icon: BarChart3 },
  { id: 'keys', label: 'Key Management', permission: 'keys.view', icon: KeyRound },
  { id: 'universal', label: 'Universal Codes', permission: 'universal.view', icon: Sparkles },
  { id: 'devices', label: 'Device Management', permission: 'devices.view', icon: Smartphone },
  { id: 'admins', label: 'Administrators', permission: 'admins.manage', icon: ShieldCheck },
  { id: 'servers', label: 'Server Management', permission: 'dashboard.view', icon: Globe },
  { id: 'urls', label: 'Subscription URLs (10)', permission: 'urls.manage', icon: Link2 },
  { id: 'features', label: 'Feature Permissions', permission: 'dashboard.view', icon: Sliders },
  { id: 'settings', label: 'Website Settings', permission: 'dashboard.view', icon: Settings },
  { id: 'logs', label: 'Security Logs', permission: 'logs.view', icon: ShieldAlert },
];

export const AdminShell: React.FC<AdminShellProps> = ({
  activeSection,
  onSelectSection,
  children,
}) => {
  const { admin, can, logout } = useAdminAuth();
  const [drawerOpen, setDrawerOpen] = useState(false);

  const visibleNav = NAV_ITEMS.filter((item) => can(item.permission));
  const current = visibleNav.find((n) => n.id === activeSection) ?? visibleNav[0];

  const handleSelect = (id: AdminSectionId) => {
    onSelectSection(id);
    setDrawerOpen(false);
  };

  const SidebarBody = (
    <div className="flex flex-col h-full">
      <div className="px-4 py-4 border-b border-zinc-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <BrandLogo size="sm" glow={false} />
          <div className="min-w-0">
            <p className="font-display text-sm font-bold text-white truncate">PRIME WIRE PRO</p>
            <p className="text-[11px] text-zinc-400">Admin Console</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setDrawerOpen(false)}
          aria-label="Close sidebar"
          className="lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav aria-label="Admin sections" className="flex-1 overflow-y-auto p-3 space-y-1">
        {visibleNav.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              className={`w-full min-h-[42px] px-3 py-2 rounded-xl flex items-center gap-3 text-xs font-medium text-left transition-colors ${
                active
                  ? 'bg-purple-600/20 text-purple-200 border border-purple-500/35'
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04] border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-purple-400' : 'text-zinc-500'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-zinc-800/80 space-y-2">
        {admin && (
          <div className="px-3 py-2 rounded-xl bg-[#07070A] border border-zinc-800/80 text-xs">
            <p className="font-semibold text-white truncate">{admin.username}</p>
            <p className="text-[11px] font-mono text-purple-300 mt-0.5">{admin.roleId}</p>
          </div>
        )}
        <button
          type="button"
          onClick={logout}
          className="w-full min-h-[42px] px-3 rounded-xl text-xs font-medium text-rose-300 hover:bg-rose-500/10 flex items-center gap-2.5 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex">
      <aside className="hidden lg:block w-64 shrink-0 bg-[#0B0B0F] border-r border-zinc-800/80 sticky top-0 h-screen">
        {SidebarBody}
      </aside>

      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            onClick={() => setDrawerOpen(false)}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
          />
          <aside className="relative z-10 w-72 max-w-[85vw] bg-[#0B0B0F] border-r border-zinc-800 h-full pt-safe pb-safe">
            {SidebarBody}
          </aside>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 h-14 bg-[#07070A]/90 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 flex items-center justify-between gap-4 pt-safe">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              aria-label="Open admin menu"
              className="lg:hidden min-w-[40px] min-h-[40px] -ml-2 flex items-center justify-center rounded-xl text-zinc-300 hover:bg-white/5"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
              <span className="text-zinc-500 hidden sm:inline">Admin</span>
              <span className="text-zinc-600 hidden sm:inline">/</span>
              <span className="font-display font-semibold text-white truncate">
                {current?.label ?? 'Overview'}
              </span>
            </div>
          </div>

          {can('keys.manage') && (
            <button
              type="button"
              onClick={() => handleSelect('keys')}
              className="min-h-[38px] px-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors"
            >
              Manage Keys
            </button>
          )}
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto pb-safe">{children}</main>
      </div>
    </div>
  );
};
