const API_BASE = ((import.meta as { env?: Record<string, string | undefined> }).env?.VITE_API_BASE_URL ?? '').replace(/\/$/, '');

const USER_TOKEN_KEY = 'pmwr_user_token';
const DEVICE_TOKEN_KEY = 'pmwr_device_token';
const ADMIN_TOKEN_KEY = 'pmwr_admin_token';

export function getStoredUserToken(): string | null {
  try {
    return localStorage.getItem(USER_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredUserTokens(sessionToken: string | null, deviceToken?: string | null) {
  try {
    if (sessionToken) localStorage.setItem(USER_TOKEN_KEY, sessionToken);
    else localStorage.removeItem(USER_TOKEN_KEY);
    if (deviceToken) localStorage.setItem(DEVICE_TOKEN_KEY, deviceToken);
  } catch {
    // Ignore storage restriction
  }
}

export function getStoredDeviceToken(): string | null {
  try {
    return localStorage.getItem(DEVICE_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getStoredAdminToken(): string | null {
  try {
    return localStorage.getItem(ADMIN_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredAdminToken(token: string | null) {
  try {
    if (token) localStorage.setItem(ADMIN_TOKEN_KEY, token);
    else localStorage.removeItem(ADMIN_TOKEN_KEY);
  } catch {
    // Ignore storage restriction
  }
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly code?: string
  ) {
    super(message);
  }
}

export async function apiRequest<T>(
  path: string,
  options: {
    method?: string;
    body?: unknown;
    scope?: 'public' | 'user' | 'admin';
  } = {}
): Promise<T> {
  const { method = 'GET', body, scope = 'public' } = options;
  const headers: Record<string, string> = {};

  if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
  }

  const deviceToken = getStoredDeviceToken();
  if (deviceToken && scope !== 'admin') {
    headers['X-Device-Token'] = deviceToken;
  }

  if (scope === 'user') {
    const token = getStoredUserToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  } else if (scope === 'admin') {
    const token = getStoredAdminToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    credentials: 'include',
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const payload = (await res.json().catch(() => ({}))) as {
    error?: string;
    code?: string;
  };

  if (!res.ok) {
    throw new ApiError(res.status, payload.error ?? `Request failed (${res.status})`, payload.code);
  }

  return payload as T;
}
