import React from 'react';
import { motion } from 'motion/react';
import { BrandLogo } from './BrandLogo';

interface LoadingScreenProps {
  message?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({
  message = 'Preparing workspace',
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-[#080808] flex flex-col items-center justify-center px-6">
      <div className="relative flex flex-col items-center">
        <div className="absolute -inset-12 rounded-full bg-purple-600/20 blur-3xl animate-ambient pointer-events-none" />
        <motion.div
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.25 }}
          className="relative"
        >
          <BrandLogo size="xl" glow />
        </motion.div>
        <h2 className="mt-5 font-display text-lg font-semibold tracking-tight text-white">
          PRIME WIRE PRO
        </h2>
        <p className="mt-1.5 text-xs text-zinc-400">{message}</p>
        <div className="mt-5 w-40 h-1 rounded-full bg-white/10 overflow-hidden">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ repeat: Infinity, duration: 1.1, ease: 'easeInOut' }}
            className="h-full w-1/2 rounded-full bg-gradient-to-r from-purple-500 via-fuchsia-400 to-purple-500"
          />
        </div>
      </div>
    </div>
  );
};
