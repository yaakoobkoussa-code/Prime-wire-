import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  Copy,
  Crosshair,
  Download,
  Eye,
  EyeOff,
  Globe,
  Laptop,
  Loader2,
  Shield,
  Sliders,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import {
  computeCountdown,
  formatDateShort,
  maskProductKey,
} from '../../utils/formatters';
import { Modal } from '../common/Modal';

interface HomeDashboardProps {
  onOpenServers: () => void;
  onOpenFeatures: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenServers,
  onOpenFeatures,
}) => {
  const { userSession, keys, servers, features, addToast } = useAppState();
  const [showKey, setShowKey] = useState(false);
  const [happModalOpen, setHappModalOpen] = useState(false);
  const [installStep, setInstallStep] = useState<0 | 1 | 2 | 3>(0);

  const activeKey = keys.find((k) => k.id === userSession?.keyRecordId);
  const currentServer = servers.find((s) => s.id === userSession?.selectedServerId) ?? servers[0];
  const currentFeature = features.find((f) => f.id === userSession?.activeFeatureId) ?? null;

  const [countdown, setCountdown] = useState(() =>
    activeKey
      ? computeCountdown(activeKey.expiresAt, activeKey.activatedAt)
      : { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false, progressPercent: 0 }
  );

  useEffect(() => {
    if (!activeKey) return;
    setCountdown(computeCountdown(activeKey.expiresAt, activeKey.activatedAt));
    const timer = window.setInterval(() => {
      setCountdown(computeCountdown(activeKey.expiresAt, activeKey.activatedAt));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activeKey]);

  if (!userSession || !activeKey) return null;

  const displayedKey = showKey ? activeKey.key : maskProductKey(activeKey.key);

  const handleCopyKey = async () => {
    try {
      await navigator.clipboard.writeText(activeKey.key);
    } catch {
      // Fallback ignored in sandbox
    }
    addToast({
      type: 'success',
      title: 'Product key copied',
      description: maskProductKey(activeKey.key),
    });
  };

  const startHappProxyDemo = () => {
    setHappModalOpen(true);
    setInstallStep(1);
    setTimeout(() => setInstallStep(2), 750);
    setTimeout(() => setInstallStep(3), 1550);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-purple-400">Client Workspace · Phase 1 Demo</p>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold tracking-tight text-white text-balance">
            Welcome back to PRIME WIRE PRO
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Manage your active region, feature profile, and HappProxy demonstration setup.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenServers}
          className="self-start sm:self-auto min-h-[44px] px-4 py-2 rounded-xl bg-[#121218] hover:bg-purple-500/12 border border-white/10 hover:border-purple-500/40 flex items-center gap-2.5 text-sm font-medium text-white transition-colors"
        >
          <span className="text-lg leading-none">{currentServer.flag}</span>
          <span>{currentServer.name}</span>
          <ChevronRight className="w-4 h-4 text-zinc-400" />
        </button>
      </div>

      {/* Main Grid: Desktop 12-col split, Mobile stacked */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Subscription Countdown Card */}
        <section className="lg:col-span-7 rounded-2xl bg-[#111116] border border-white/8 p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <Clock className="w-4 h-4 text-purple-400" />
                <span>Subscription Countdown</span>
              </div>
              <div className="mt-3 flex items-baseline gap-4 flex-wrap">
                <div>
                  <span className="font-display text-4xl sm:text-5xl font-bold text-white tabular-nums">
                    {countdown.days}
                  </span>
                  <span className="ml-1.5 text-sm text-zinc-400">Days</span>
                </div>
                <div>
                  <span className="font-display text-4xl sm:text-5xl font-bold text-purple-400 tabular-nums">
                    {String(countdown.hours).padStart(2, '0')}
                  </span>
                  <span className="ml-1.5 text-sm text-zinc-400">Hours</span>
                </div>
                <div className="text-lg font-mono text-zinc-300 tabular-nums">
                  {String(countdown.minutes).padStart(2, '0')}m{' '}
                  {String(countdown.seconds).padStart(2, '0')}s
                </div>
              </div>
            </div>

            <span className="text-xs font-medium text-emerald-400 whitespace-nowrap shrink-0">
              {countdown.isExpired ? 'Expired' : 'Active Plan'}
            </span>
          </div>

          <div className="mt-6">
            <div className="h-2 w-full rounded-full bg-white/8 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-600 to-fuchsia-400 transition-all duration-500"
                style={{ width: `${countdown.progressPercent}%` }}
              />
            </div>
            <div className="mt-4 pt-4 border-t border-white/8 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Activated</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateShort(activeKey.activatedAt)}
                </p>
              </div>
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Expires</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateShort(activeKey.expiresAt)}
                </p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5" />
                  <span>Device Usage</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {activeKey.devicesUsed} / {activeKey.deviceLimit} Devices
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Product Key & HappProxy Column */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          {/* Product Key Card */}
          <section className="rounded-2xl bg-[#111116] border border-white/8 p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-zinc-400">Licensed Product Key</span>
              <span className="text-xs text-zinc-400 tabular-nums">
                {activeKey.durationDays}d Plan
              </span>
            </div>

            <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-[#080808] border border-white/8 px-3.5 py-2.5">
              <code className="font-mono text-sm text-zinc-100 tracking-wider truncate">
                {displayedKey}
              </code>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowKey((v) => !v)}
                  aria-label={showKey ? 'Hide product key' : 'Show product key'}
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-white/8 text-zinc-400 hover:text-white flex items-center justify-center transition-colors"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={handleCopyKey}
                  aria-label="Copy product key"
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-purple-500/15 text-zinc-400 hover:text-purple-300 flex items-center justify-center transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>

          {/* HappProxy Installation Card */}
          <section className="flex-1 rounded-2xl bg-[#13101B] border border-purple-500/30 p-5 flex flex-col justify-between shadow-[0_0_32px_rgba(147,51,234,0.12)]">
            <div>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="font-display text-base font-semibold text-white">
                      HappProxy Configuration
                    </h2>
                    <p className="text-xs text-zinc-400">Routing client profile</p>
                  </div>
                </div>
              </div>
              <p className="mt-3 text-xs text-zinc-300 leading-relaxed">
                Preview the HappProxy configuration workflow for{' '}
                <span className="text-white font-medium">{currentServer.name}</span>
                {currentFeature ? ` with ${currentFeature.title}` : ''}.
              </p>
            </div>

            <button
              type="button"
              onClick={startHappProxyDemo}
              className="mt-4 w-full min-h-[46px] rounded-xl bg-purple-600 hover:bg-purple-500 active:scale-[0.99] text-sm font-semibold text-white shadow-[0_0_20px_rgba(147,51,234,0.35)] flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Install Config</span>
            </button>
          </section>
        </div>
      </div>

      {/* Bottom 2 Interactive Status Cards: Server Region & Active Feature */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <button
          type="button"
          onClick={onOpenServers}
          className="text-left rounded-2xl bg-[#111116] hover:bg-[#15151C] border border-white/8 hover:border-purple-500/40 p-5 flex items-center justify-between gap-4 transition-all group min-h-[96px]"
        >
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-[#080808] border border-white/10 flex items-center justify-center text-2xl shrink-0">
              {currentServer.flag}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Globe className="w-3.5 h-3.5 text-purple-400" />
                <span>Current Server Region</span>
              </div>
              <p className="mt-0.5 font-display text-lg font-semibold text-white truncate">
                {currentServer.name}
              </p>
              <p className="text-xs text-zinc-400 font-mono tabular-nums">
                {currentServer.code} · {currentServer.simulatedLatencyMs} ms (Demo)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-medium text-purple-400 shrink-0">
            <span>Change</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>

        <button
          type="button"
          onClick={onOpenFeatures}
          className="text-left rounded-2xl bg-[#111116] hover:bg-[#15151C] border border-white/8 hover:border-purple-500/40 p-5 flex items-center justify-between gap-4 transition-all group min-h-[96px]"
        >
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-[#080808] border border-white/10 flex items-center justify-center text-purple-400 shrink-0">
              {currentFeature ? (
                <Crosshair className="w-5 h-5" />
              ) : (
                <Sliders className="w-5 h-5 text-zinc-500" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs text-zinc-400">Current Active Feature</div>
              <p className="mt-0.5 font-display text-lg font-semibold text-white truncate">
                {currentFeature ? currentFeature.title : 'None Active'}
              </p>
              <p className="text-xs text-zinc-400">
                {currentFeature
                  ? 'Single active profile enforced'
                  : 'Select ONLY AIM POINT or AIM POINT AND MOCO MARK'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-medium text-purple-400 shrink-0">
            <span>Configure</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>
      </div>

      {/* HappProxy Interactive Demonstration Modal */}
      <Modal
        open={happModalOpen}
        onClose={() => setHappModalOpen(false)}
        title="HappProxy Install Demonstration"
        subtitle="Phase 1 visual preview — no real system proxy or file is installed"
      >
        <div className="space-y-4">
          <div className="rounded-xl bg-[#080808] border border-white/10 p-4 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Target Region</span>
              <span className="text-white font-medium">
                {currentServer.flag} {currentServer.name} ({currentServer.code})
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Selected Feature</span>
              <span className="text-white font-medium">
                {currentFeature ? currentFeature.title : 'Default Base Routing'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Backend Status</span>
              <span className="text-purple-300 font-medium">Visual Simulation Only</span>
            </div>
          </div>

          <div className="space-y-2.5">
            {[
              { step: 1, label: 'Preparing HappProxy profile schema' },
              { step: 2, label: `Binding ${currentServer.name} demonstration parameters` },
              { step: 3, label: 'Demonstration sequence ready for Phase 2 backend binding' },
            ].map((item) => {
              const done = installStep > item.step || (installStep === 3 && item.step === 3);
              const active = installStep === item.step && item.step < 3;
              return (
                <div
                  key={item.step}
                  className="flex items-center gap-3 rounded-xl bg-white/[0.03] border border-white/8 px-3.5 py-3 text-sm"
                >
                  {done ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : active ? (
                    <Loader2 className="w-4 h-4 text-purple-400 animate-spin shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-zinc-600 shrink-0" />
                  )}
                  <span className={done || active ? 'text-zinc-100' : 'text-zinc-500'}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setHappModalOpen(false)}
              className="min-h-[44px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-sm font-semibold text-white transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </Modal>
    </motion.div>
  );
};
