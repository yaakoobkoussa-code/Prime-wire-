import React, { useState } from 'react';
import {
  Activity,
  ArrowLeft,
  BarChart3,
  Globe,
  KeyRound,
  Link2,
  LogOut,
  Menu,
  PlusCircle,
  Settings,
  ShieldAlert,
  Sliders,
  Smartphone,
  Users,
  X,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { AdminSection } from '../../types';
import { BrandLogo } from '../common/BrandLogo';

interface AdminShellProps {
  activeSection: AdminSection;
  onSelectSection: (section: AdminSection) => void;
  onBackToClient: () => void;
  children: React.ReactNode;
}

const ADMIN_NAV: {
  id: AdminSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'dashboard', label: 'Dashboard Statistics', icon: BarChart3 },
  { id: 'key-generator', label: 'Product Key Generator', icon: PlusCircle },
  { id: 'keys', label: 'Key Management', icon: KeyRound },
  { id: 'distributors', label: 'Distributor Management', icon: Users },
  { id: 'subscription-urls', label: 'Subscription URLs (10)', icon: Link2 },
  { id: 'servers', label: 'Server Management', icon: Globe },
  { id: 'features', label: 'Feature Permissions', icon: Sliders },
  { id: 'device-protection', label: 'Device Protection', icon: Smartphone },
  { id: 'security-logs', label: 'Security Logs', icon: ShieldAlert },
  { id: 'settings', label: 'Website & Security Settings', icon: Settings },
];

export const AdminShell: React.FC<AdminShellProps> = ({
  activeSection,
  onSelectSection,
  onBackToClient,
  children,
}) => {
  const { logoutAdmin, settings } = useAppState();
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const currentNav = ADMIN_NAV.find((n) => n.id === activeSection) ?? ADMIN_NAV[0];

  const handleSelect = (id: AdminSection) => {
    onSelectSection(id);
    setMobileDrawerOpen(false);
  };

  const SidebarContent = (
    <div className="flex flex-col h-full">
      <div className="px-4 py-4 border-b border-zinc-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <BrandLogo size="sm" glow={false} />
          <div className="min-w-0">
            <p className="font-display text-sm font-bold text-white truncate">
              {settings.websiteTitle}
            </p>
            <p className="text-[11px] text-zinc-400">Admin Console</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMobileDrawerOpen(false)}
          aria-label="Close sidebar"
          className="lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav aria-label="Admin sections" className="flex-1 overflow-y-auto p-3 space-y-1">
        {ADMIN_NAV.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              className={`w-full min-h-[42px] px-3 py-2 rounded-xl flex items-center gap-3 text-xs font-medium text-left transition-colors ${
                active
                  ? 'bg-purple-600/20 text-purple-200 border border-purple-500/35'
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04] border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-purple-400' : 'text-zinc-500'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-zinc-800/80 space-y-1.5">
        <button
          type="button"
          onClick={onBackToClient}
          className="w-full min-h-[42px] px-3 rounded-xl text-xs font-medium text-zinc-300 hover:text-white hover:bg-white/[0.04] flex items-center gap-2.5 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-zinc-400" />
          <span>Client Application</span>
        </button>
        <button
          type="button"
          onClick={logoutAdmin}
          className="w-full min-h-[42px] px-3 rounded-xl text-xs font-medium text-rose-300 hover:bg-rose-500/10 flex items-center gap-2.5 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out Admin</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 bg-[#0B0B0F] border-r border-zinc-800/80 sticky top-0 h-screen">
        {SidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            onClick={() => setMobileDrawerOpen(false)}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
          />
          <aside className="relative z-10 w-72 max-w-[85vw] bg-[#0B0B0F] border-r border-zinc-800 h-full pt-safe pb-safe">
            {SidebarContent}
          </aside>
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 h-14 bg-[#07070A]/90 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 flex items-center justify-between gap-4 pt-safe">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileDrawerOpen(true)}
              aria-label="Open admin menu"
              className="lg:hidden min-w-[40px] min-h-[40px] -ml-2 flex items-center justify-center rounded-xl text-zinc-300 hover:bg-white/5"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
              <span className="text-zinc-500 hidden sm:inline">Admin</span>
              <span className="text-zinc-600 hidden sm:inline">/</span>
              <span className="font-display font-semibold text-white truncate">
                {currentNav.label}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-zinc-400 mr-2">
              <Activity className="w-3.5 h-3.5 text-purple-400" />
              <span>Phase 1 Demo</span>
            </span>
            <button
              type="button"
              onClick={() => handleSelect('key-generator')}
              className="min-h-[38px] px-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors"
            >
              Generate Key
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto pb-safe">
          {children}
        </main>
      </div>
    </div>
  );
};
