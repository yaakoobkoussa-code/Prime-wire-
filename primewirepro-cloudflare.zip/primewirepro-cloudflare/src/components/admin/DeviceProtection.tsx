import React from 'react';
import { Ban, CheckCircle2, ShieldAlert, Smartphone, Unlink } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { formatDateTime, maskProductKey } from '../../utils/formatters';
import { ToggleSwitch } from '../common/ToggleSwitch';

export const DeviceProtection: React.FC = () => {
  const { devices, settings, updateDeviceStatus, unbindDevice, updateSettings } = useAppState();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Device Protection</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Hardware binding policies, registered device slots, and multi-device protection controls.
        </p>
      </div>

      {/* Protection Policies */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-sm font-semibold text-white">
              Strict Hardware Binding
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Bind product keys to registered device fingerprints on activation.
            </p>
          </div>
          <ToggleSwitch
            checked={settings.strictHwidBinding}
            label="Toggle strict hardware binding"
            onChange={() => updateSettings({ strictHwidBinding: !settings.strictHwidBinding })}
          />
        </div>

        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-sm font-semibold text-white">
              Auto-Block Concurrent Sharing
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Flag and block keys exceeding simultaneous device slot limits.
            </p>
          </div>
          <ToggleSwitch
            checked={settings.autoBlockMultiDevice}
            label="Toggle auto-block concurrent sharing"
            onChange={() =>
              updateSettings({ autoBlockMultiDevice: !settings.autoBlockMultiDevice })
            }
          />
        </div>
      </div>

      {/* Registered Devices List */}
      <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
        <div className="px-5 py-4 border-b border-zinc-800/80 flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-white">
            Registered Devices ({devices.length})
          </h2>
          <span className="text-xs text-zinc-400">Phase 1 Demonstration Records</span>
        </div>

        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 bg-[#0B0B10]">
                <th className="py-3 px-4 font-medium">Device</th>
                <th className="py-3 px-4 font-medium">Hardware Hash</th>
                <th className="py-3 px-4 font-medium">Bound Key</th>
                <th className="py-3 px-4 font-medium">Last Active</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70">
              {devices.map((dev) => (
                <tr key={dev.id} className="hover:bg-white/[0.02]">
                  <td className="py-3.5 px-4">
                    <p className="font-medium text-white">{dev.deviceName}</p>
                    <p className="text-zinc-500">
                      {dev.platform} · {dev.ipMasked}
                    </p>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-zinc-300">{dev.hardwareHash}</td>
                  <td className="py-3.5 px-4 font-mono text-zinc-300">
                    {maskProductKey(dev.boundKey)}
                  </td>
                  <td className="py-3.5 px-4 text-zinc-400 tabular-nums">
                    {formatDateTime(dev.lastActiveAt)}
                  </td>
                  <td className="py-3.5 px-4 capitalize">
                    <span
                      className={
                        dev.status === 'trusted'
                          ? 'text-emerald-400'
                          : dev.status === 'flagged'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }
                    >
                      {dev.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center justify-end gap-1.5">
                      {dev.status !== 'trusted' && (
                        <button
                          type="button"
                          onClick={() => updateDeviceStatus(dev.id, 'trusted')}
                          title="Mark trusted"
                          className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-emerald-500/15 text-zinc-400 hover:text-emerald-400 flex items-center justify-center"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      )}
                      {dev.status !== 'blocked' && (
                        <button
                          type="button"
                          onClick={() => updateDeviceStatus(dev.id, 'blocked')}
                          title="Block device"
                          className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-rose-500/15 text-zinc-400 hover:text-rose-400 flex items-center justify-center"
                        >
                          <Ban className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => unbindDevice(dev.id)}
                        title="Unbind device slot"
                        className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center"
                      >
                        <Unlink className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Device Cards */}
        <div className="md:hidden divide-y divide-zinc-800/70">
          {devices.map((dev) => (
            <div key={dev.id} className="p-4 space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{dev.deviceName}</p>
                    <p className="text-xs text-zinc-400 font-mono truncate">{dev.hardwareHash}</p>
                  </div>
                </div>
                <span
                  className={`text-xs font-medium capitalize ${
                    dev.status === 'trusted'
                      ? 'text-emerald-400'
                      : dev.status === 'flagged'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {dev.status}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="font-mono">{maskProductKey(dev.boundKey)}</span>
                <span>{dev.platform}</span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDeviceStatus(dev.id, dev.status === 'blocked' ? 'trusted' : 'blocked')
                  }
                  className="flex-1 min-h-[36px] rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-200 flex items-center justify-center gap-1.5"
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  <span>{dev.status === 'blocked' ? 'Unblock' : 'Block'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => unbindDevice(dev.id)}
                  className="flex-1 min-h-[36px] rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-300 flex items-center justify-center gap-1.5"
                >
                  <Unlink className="w-3.5 h-3.5" />
                  <span>Unbind</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
