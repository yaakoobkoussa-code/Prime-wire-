import React from 'react';
import { Activity, Globe, Users } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ServerRegion } from '../../types';

export const ServerManagement: React.FC = () => {
  const { servers, updateServer } = useAppState();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Server Management</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Manage operational status, capacity limits, and routing notes for the 5 regional nodes.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {servers.map((srv) => {
          const loadPct = Math.min(
            100,
            Math.round((srv.activeUsersDemo / Math.max(1, srv.capacityLimit)) * 100)
          );

          return (
            <div
              key={srv.id}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl leading-none">{srv.flag}</span>
                  <div>
                    <h2 className="font-display text-base font-semibold text-white">{srv.name}</h2>
                    <p className="text-xs font-mono text-zinc-500">{srv.code}</p>
                  </div>
                </div>

                <select
                  aria-label={`Status for ${srv.name}`}
                  value={srv.status}
                  onChange={(e) =>
                    updateServer(srv.id, {
                      status: e.target.value as ServerRegion['status'],
                    })
                  }
                  className={`min-h-[36px] px-2.5 rounded-lg bg-[#07070A] border border-zinc-800 text-xs font-medium focus:outline-none focus:border-purple-500 ${
                    srv.status === 'operational'
                      ? 'text-emerald-400'
                      : srv.status === 'high_load'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  <option value="operational">Operational</option>
                  <option value="high_load">Elevated Load</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#07070A] border border-zinc-800/80 p-3 text-xs">
                <div>
                  <span className="text-zinc-500 flex items-center gap-1">
                    <Activity className="w-3 h-3 text-purple-400" />
                    Latency (Demo)
                  </span>
                  <p className="mt-1 font-mono text-white tabular-nums">
                    {srv.simulatedLatencyMs} ms
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500 flex items-center gap-1">
                    <Users className="w-3 h-3 text-purple-400" />
                    Load
                  </span>
                  <p className="mt-1 font-mono text-white tabular-nums">
                    {srv.activeUsersDemo} / {srv.capacityLimit} ({loadPct}%)
                  </p>
                </div>
              </div>

              <div>
                <label
                  htmlFor={`cap-${srv.id}`}
                  className="block text-xs font-medium text-zinc-400 mb-1"
                >
                  Capacity Threshold
                </label>
                <input
                  id={`cap-${srv.id}`}
                  type="number"
                  min={100}
                  max={5000}
                  step={50}
                  value={srv.capacityLimit}
                  onChange={(e) =>
                    updateServer(srv.id, {
                      capacityLimit: Math.max(100, Number(e.target.value) || 500),
                    })
                  }
                  className="w-full min-h-[40px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs font-mono text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label
                  htmlFor={`note-${srv.id}`}
                  className="block text-xs font-medium text-zinc-400 mb-1"
                >
                  Region Note
                </label>
                <div className="relative flex items-center">
                  <Globe className="w-3.5 h-3.5 text-zinc-500 absolute left-3 pointer-events-none" />
                  <input
                    id={`note-${srv.id}`}
                    type="text"
                    value={srv.routingNote}
                    onChange={(e) => updateServer(srv.id, { routingNote: e.target.value })}
                    className="w-full min-h-[40px] pl-9 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-200 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
