import React, { useMemo, useState } from 'react';
import { Check, Copy, PlusCircle, RefreshCw } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ActivationRule, FeatureId, ProductKeyRecord, ServerRegionId } from '../../types';
import {
  formatDateShort,
  formatProductKeyInput,
  generateDemoProductKey,
} from '../../utils/formatters';

export const KeyGenerator: React.FC = () => {
  const { servers, features, distributors, generateKeys, addToast } = useAppState();

  const [count, setCount] = useState(1);
  const [customKey, setCustomKey] = useState(() => generateDemoProductKey());
  const [durationDays, setDurationDays] = useState(30);
  const [deviceLimit, setDeviceLimit] = useState(2);
  const [allowedServers, setAllowedServers] = useState<ServerRegionId[]>([
    'brazil',
    'india',
    'singapore',
    'europe',
    'bangladesh',
  ]);
  const [allowedFeatures, setAllowedFeatures] = useState<FeatureId[]>([
    'only_aim_point',
    'aim_point_moco_mark',
  ]);
  const [distributorId, setDistributorId] = useState(distributors[0]?.id ?? '');
  const [activationRule, setActivationRule] = useState<ActivationRule>('on_first_login');
  const [recentOutput, setRecentOutput] = useState<ProductKeyRecord[]>([]);

  const expirationPreview = useMemo(() => {
    return new Date(Date.now() + durationDays * 86_400_000).toISOString();
  }, [durationDays]);

  const toggleServer = (id: ServerRegionId) => {
    setAllowedServers((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((s) => s !== id) : prev) : [...prev, id]
    );
  };

  const toggleFeature = (id: FeatureId) => {
    setAllowedFeatures((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((f) => f !== id) : prev) : [...prev, id]
    );
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const created = generateKeys({
      count,
      durationDays,
      deviceLimit,
      allowedServers,
      allowedFeatures,
      distributorId,
      activationRule,
      customKey: count === 1 ? customKey : undefined,
    });
    setRecentOutput(created);
    setCustomKey(generateDemoProductKey());
  };

  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Ignore sandbox restriction
    }
    addToast({ type: 'success', title: 'Copied to clipboard' });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Product Key Generator</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Generate Phase 1 demonstration keys in PMWR-XXXX-XXXX-XXXX format with granular rules.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleGenerate}
          className="lg:col-span-7 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6 space-y-5"
        >
          {/* Quantity & Key Preview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="gen-count" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Batch Quantity
              </label>
              <input
                id="gen-count"
                type="number"
                min={1}
                max={25}
                value={count}
                onChange={(e) => setCount(Math.min(25, Math.max(1, Number(e.target.value) || 1)))}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono tabular-nums text-white focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label htmlFor="gen-preview" className="block text-xs font-medium text-zinc-300 mb-1.5">
                {count === 1 ? 'Key String (Editable)' : 'Format Template'}
              </label>
              <div className="flex items-center gap-2">
                <input
                  id="gen-preview"
                  type="text"
                  disabled={count > 1}
                  value={count > 1 ? 'PMWR-AUTO-BATCH-DEMO' : customKey}
                  onChange={(e) => setCustomKey(formatProductKeyInput(e.target.value))}
                  maxLength={19}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white disabled:opacity-60 focus:outline-none focus:border-purple-500"
                />
                {count === 1 && (
                  <button
                    type="button"
                    onClick={() => setCustomKey(generateDemoProductKey())}
                    aria-label="Randomize key"
                    className="min-w-[44px] min-h-[44px] rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 flex items-center justify-center text-zinc-300"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Subscription Duration & Device Limit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                Subscription Duration
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[1, 7, 30, 90, 180, 365].map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setDurationDays(days)}
                    className={`min-h-[40px] rounded-xl text-xs font-medium border tabular-nums transition-colors ${
                      durationDays === days
                        ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                        : 'bg-[#07070A] border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {days}d
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="gen-devices" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Device Limit
              </label>
              <select
                id="gen-devices"
                value={deviceLimit}
                onChange={(e) => setDeviceLimit(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n} Device{n > 1 ? 's' : ''}
                  </option>
                ))}
              </select>

              <p className="mt-2 text-xs text-zinc-400">
                Projected Expiration:{' '}
                <span className="text-zinc-200 font-medium tabular-nums">
                  {formatDateShort(expirationPreview)}
                </span>
              </p>
            </div>
          </div>

          {/* Distributor & Activation Rule */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="gen-dist" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Distributor Assignment
              </label>
              <select
                id="gen-dist"
                value={distributorId}
                onChange={(e) => setDistributorId(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
              >
                {distributors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.handle})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="gen-rule" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Activation Rules
              </label>
              <select
                id="gen-rule"
                value={activationRule}
                onChange={(e) => setActivationRule(e.target.value as ActivationRule)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
              >
                <option value="on_first_login">Start timer on first login</option>
                <option value="immediate">Immediate activation</option>
              </select>
            </div>
          </div>

          {/* Server Permissions */}
          <div>
            <p className="text-xs font-medium text-zinc-300 mb-2">Server Permissions (5 Regions)</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {servers.map((srv) => {
                const selected = allowedServers.includes(srv.id);
                return (
                  <button
                    key={srv.id}
                    type="button"
                    onClick={() => toggleServer(srv.id)}
                    className={`min-h-[42px] px-3 rounded-xl border text-xs font-medium flex items-center justify-between gap-2 transition-colors ${
                      selected
                        ? 'bg-purple-600/15 border-purple-500/60 text-white'
                        : 'bg-[#07070A] border-zinc-800 text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    <span className="truncate">
                      {srv.flag} {srv.name}
                    </span>
                    {selected && <Check className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Allowed Features (Only the 2 requested features) */}
          <div>
            <p className="text-xs font-medium text-zinc-300 mb-2">Allowed Features</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {features.map((feat) => {
                const selected = allowedFeatures.includes(feat.id);
                return (
                  <button
                    key={feat.id}
                    type="button"
                    onClick={() => toggleFeature(feat.id)}
                    className={`min-h-[46px] px-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between gap-2 transition-colors ${
                      selected
                        ? 'bg-purple-600/15 border-purple-500/60 text-purple-200'
                        : 'bg-[#07070A] border-zinc-800 text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    <span className="truncate">{feat.title}</span>
                    {selected && <Check className="w-4 h-4 text-purple-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Generate {count > 1 ? `${count} Keys` : 'Product Key'}</span>
          </button>
        </form>

        {/* Generated Keys Output */}
        <section className="lg:col-span-5 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">Generated Output</h2>
              <p className="text-xs text-zinc-400">Ready to test in client login</p>
            </div>
            {recentOutput.length > 0 && (
              <button
                type="button"
                onClick={() => copyText(recentOutput.map((r) => r.key).join('\n'))}
                className="min-h-[36px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-200 inline-flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy All</span>
              </button>
            )}
          </div>

          {recentOutput.length === 0 ? (
            <div className="rounded-xl border border-dashed border-zinc-800 p-8 text-center">
              <p className="text-sm text-zinc-400">No keys generated in this session yet.</p>
              <p className="text-xs text-zinc-500 mt-1">
                Configure options on the left and click Generate Product Key.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {recentOutput.map((rec) => (
                <div
                  key={rec.id}
                  className="rounded-xl bg-[#07070A] border border-zinc-800 px-3.5 py-3 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <p className="font-mono text-xs sm:text-sm text-purple-200 truncate">
                      {rec.key}
                    </p>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      {rec.durationDays}d · {rec.deviceLimit} devices · {rec.distributorName}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyText(rec.key)}
                    aria-label={`Copy ${rec.key}`}
                    className="min-w-[38px] min-h-[38px] rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center shrink-0"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
