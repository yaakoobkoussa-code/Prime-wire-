import React, { useMemo, useState } from 'react';
import { Download, Search } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { SecurityLogEntry } from '../../types';
import { downloadCsv, formatDateTime } from '../../utils/formatters';

export const SecurityLogs: React.FC = () => {
  const { securityLogs, addToast } = useAppState();
  const [search, setSearch] = useState('');
  const [severity, setSeverity] = useState<'all' | SecurityLogEntry['severity']>('all');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return securityLogs.filter((log) => {
      if (severity !== 'all' && log.severity !== severity) return false;
      if (
        q &&
        !log.event.toLowerCase().includes(q) &&
        !log.actor.toLowerCase().includes(q) &&
        !log.target.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [securityLogs, search, severity]);

  const handleExport = () => {
    downloadCsv(
      'prime-wire-pro-security-logs.csv',
      filtered.map((l) => ({
        timestamp: l.timestamp,
        severity: l.severity,
        event: l.event,
        actor: l.actor,
        target: l.target,
        region: l.region,
      }))
    );
    addToast({ type: 'success', title: 'Security logs exported' });
  };

  const severityColor = (sev: SecurityLogEntry['severity']) => {
    if (sev === 'critical') return 'text-rose-400';
    if (sev === 'warning') return 'text-amber-400';
    return 'text-emerald-400';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Security Logs</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Audit stream of simulated authentication, key actions, and device protection events.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExport}
          disabled={filtered.length === 0}
          className="self-start sm:self-auto min-h-[44px] px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-semibold text-white inline-flex items-center gap-2 transition-colors"
        >
          <Download className="w-4 h-4 text-purple-400" />
          <span>Export Logs</span>
        </button>
      </div>

      <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 flex items-center">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by event, actor, or target..."
            className="w-full min-h-[42px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
          />
        </div>
        <div className="flex items-center gap-2">
          {(['all', 'info', 'warning', 'critical'] as const).map((sev) => (
            <button
              key={sev}
              type="button"
              onClick={() => setSeverity(sev)}
              className={`min-h-[40px] px-3 rounded-xl text-xs font-medium capitalize border transition-colors ${
                severity === sev
                  ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                  : 'bg-[#07070A] border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 bg-[#0B0B10]">
                <th className="py-3 px-4 font-medium">Timestamp</th>
                <th className="py-3 px-4 font-medium">Severity</th>
                <th className="py-3 px-4 font-medium">Event</th>
                <th className="py-3 px-4 font-medium">Actor</th>
                <th className="py-3 px-4 font-medium">Target</th>
                <th className="py-3 px-4 font-medium text-right">Region</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70">
              {filtered.map((log) => (
                <tr key={log.id} className="hover:bg-white/[0.02]">
                  <td className="py-3.5 px-4 font-mono text-zinc-400 tabular-nums whitespace-nowrap">
                    {formatDateTime(log.timestamp)}
                  </td>
                  <td className={`py-3.5 px-4 font-semibold capitalize ${severityColor(log.severity)}`}>
                    {log.severity}
                  </td>
                  <td className="py-3.5 px-4 text-zinc-100">{log.event}</td>
                  <td className="py-3.5 px-4 font-mono text-zinc-400">{log.actor}</td>
                  <td className="py-3.5 px-4 text-zinc-300">{log.target}</td>
                  <td className="py-3.5 px-4 text-right text-zinc-400">{log.region}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden divide-y divide-zinc-800/70">
          {filtered.map((log) => (
            <div key={log.id} className="p-4 space-y-1.5 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className={`font-semibold capitalize ${severityColor(log.severity)}`}>
                  {log.severity}
                </span>
                <span className="font-mono text-zinc-500 tabular-nums">
                  {formatDateTime(log.timestamp)}
                </span>
              </div>
              <p className="text-sm font-medium text-white">{log.event}</p>
              <p className="text-zinc-400 font-mono">
                {log.actor} · {log.target}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
