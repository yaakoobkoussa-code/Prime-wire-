export const PRODUCT_KEY_REGEX = /^PMWR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

export function formatProductKeyInput(raw: string): string {
  const cleaned = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  // Ensure PMWR prefix if user starts typing raw characters or already typed PMWR
  const body = cleaned.startsWith('PMWR') ? cleaned.slice(4) : cleaned;
  const trimmed = body.slice(0, 12);
  const parts: string[] = [];
  for (let i = 0; i < trimmed.length; i += 4) {
    parts.push(trimmed.slice(i, i + 4));
  }
  if (!cleaned) return '';
  if (cleaned.length <= 4 && 'PMWR'.startsWith(cleaned)) {
    return cleaned;
  }
  return parts.length > 0 ? `PMWR-${parts.join('-')}` : 'PMWR-';
}

export function generateDemoProductKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const block = () =>
    Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `PMWR-${block()}-${block()}-${block()}`;
}

export function maskProductKey(key: string): string {
  const segments = key.split('-');
  if (segments.length !== 4) return 'PMWR-••••-••••-••••';
  return `${segments[0]}-••••-••••-${segments[3]}`;
}

export function formatDateShort(iso: string | null): string {
  if (!iso) return 'Pending activation';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return 'Invalid date';
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateTime(iso: string | null): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export interface CountdownParts {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  progressPercent: number;
}

export function computeCountdown(expiresAtIso: string, activatedAtIso: string | null): CountdownParts {
  const now = Date.now();
  const end = new Date(expiresAtIso).getTime();
  const start = activatedAtIso ? new Date(activatedAtIso).getTime() : now - 86400000;
  const diff = Math.max(0, end - now);

  const totalSpan = Math.max(1, end - start);
  const progressPercent = Math.min(100, Math.max(0, Math.round((diff / totalSpan) * 100)));

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  return {
    days,
    hours,
    minutes,
    seconds,
    isExpired: diff <= 0,
    progressPercent,
  };
}

export function detectClientDeviceInfo(): { deviceLabel: string; platformName: string } {
  if (typeof navigator === 'undefined') {
    return { deviceLabel: 'Mobile Device', platformName: 'Web Client' };
  }
  const ua = navigator.userAgent;
  if (/iPhone/i.test(ua)) return { deviceLabel: 'iPhone Client', platformName: 'iOS Safari / PWA' };
  if (/iPad/i.test(ua)) return { deviceLabel: 'iPad Client', platformName: 'iPadOS' };
  if (/Android/i.test(ua)) return { deviceLabel: 'Android Device', platformName: 'Android Mobile' };
  if (/Macintosh/i.test(ua)) return { deviceLabel: 'Mac Workstation', platformName: 'macOS Browser' };
  if (/Windows/i.test(ua)) return { deviceLabel: 'Windows Desktop', platformName: 'Windows Browser' };
  return { deviceLabel: 'Desktop Client', platformName: 'Linux / Web' };
}

export function downloadCsv(filename: string, rows: Record<string, string | number | boolean>[]): void {
  if (rows.length === 0) return;
  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      headers
        .map((h) => {
          const val = String(row[h] ?? '').replace(/"/g, '""');
          return `"${val}"`;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
