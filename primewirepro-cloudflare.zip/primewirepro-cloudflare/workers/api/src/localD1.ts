import fs from 'fs';
import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import { D1Database, D1PreparedStatement } from './types';

class LocalPreparedStatement implements D1PreparedStatement {
  private values: unknown[] = [];

  constructor(
    private readonly db: DatabaseSync,
    private readonly query: string
  ) {}

  bind(...values: unknown[]): D1PreparedStatement {
    this.values = values.map((v) => (v === undefined ? null : v));
    return this;
  }

  async first<T = Record<string, unknown>>(colName?: string): Promise<T | null> {
    const stmt = this.db.prepare(this.query);
    const row = stmt.get(...(this.values as (string | number | null | Uint8Array)[])) as
      | Record<string, unknown>
      | undefined;
    if (!row) return null;
    if (colName) {
      return (row[colName] as T) ?? null;
    }
    return row as T;
  }

  async run<T = unknown>(): Promise<{
    success: boolean;
    meta: { changes?: number; last_row_id?: number };
  }> {
    const stmt = this.db.prepare(this.query);
    const info = stmt.run(...(this.values as (string | number | null | Uint8Array)[]));
    return {
      success: true,
      meta: {
        changes: Number(info.changes ?? 0),
        last_row_id: Number(info.lastInsertRowid ?? 0),
      },
    };
  }

  async all<T = Record<string, unknown>>(): Promise<{ results: T[]; success: boolean }> {
    const stmt = this.db.prepare(this.query);
    const rows = stmt.all(...(this.values as (string | number | null | Uint8Array)[])) as T[];
    return { results: rows, success: true };
  }
}

export class LocalD1Database implements D1Database {
  public readonly sqlite: DatabaseSync;

  constructor(dbFilePath: string) {
    if (dbFilePath !== ':memory:') {
      fs.mkdirSync(path.dirname(dbFilePath), { recursive: true });
    }
    this.sqlite = new DatabaseSync(dbFilePath);
    this.sqlite.exec('PRAGMA foreign_keys = ON;');
    if (dbFilePath !== ':memory:') {
      this.sqlite.exec('PRAGMA journal_mode = DELETE;');
      this.sqlite.exec('PRAGMA synchronous = FULL;');
      this.sqlite.exec('PRAGMA busy_timeout = 5000;');
    }
  }

  prepare(query: string): D1PreparedStatement {
    return new LocalPreparedStatement(this.sqlite, query);
  }

  async batch<T = unknown>(statements: D1PreparedStatement[]): Promise<T[]> {
    const results: T[] = [];
    this.sqlite.exec('BEGIN');
    try {
      for (const s of statements) {
        results.push((await s.run()) as T);
      }
      this.sqlite.exec('COMMIT');
      return results;
    } catch (err) {
      this.sqlite.exec('ROLLBACK');
      throw err;
    }
  }

  async exec(query: string): Promise<unknown> {
    this.sqlite.exec(query);
    return { success: true };
  }

  runMigrations(migrationsDir: string): void {
    const files = fs
      .readdirSync(migrationsDir)
      .filter((f) => f.endsWith('.sql'))
      .sort();
    for (const file of files) {
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
      this.sqlite.exec(sql);
    }
  }
}
