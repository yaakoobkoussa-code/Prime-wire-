import {
  hashPassword,
  randomHex,
  randomId,
  sha256Hex,
  signDeviceToken,
  timingSafeEqualStr,
  verifyPassword,
  verifySignedDeviceToken,
} from './crypto';
import {
  checkRateLimit,
  expireStaleCredentials,
  getClientIpHash,
  hasPermission,
  resetRateLimit,
  resolveAdminPermissions,
  writeSecurityLog,
} from './db';
import {
  AdminRecord,
  AdminRoleId,
  AuthenticatedAdmin,
  FeatureId,
  ServerId,
  WorkerEnv,
} from './types';

const VALID_SERVERS: ServerId[] = ['brazil', 'india', 'singapore', 'europe', 'bangladesh'];
const VALID_FEATURES: FeatureId[] = ['aim_point', 'aim_point_moco_mark'];
const VALID_ROLES: AdminRoleId[] = ['SUPER_ADMIN', 'ADMIN', 'SUPPORT', 'VIEW_ONLY'];
const PRODUCT_KEY_REGEX = /^PMWR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

function parseCookies(cookieHeader: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    if (key) out[key] = decodeURIComponent(val);
  }
  return out;
}

function buildCookieHeader(
  name: string,
  value: string,
  maxAgeSeconds: number,
  isHttps: boolean,
  crossSite: boolean
): string {
  const sameSite = isHttps && crossSite ? 'None' : 'Lax';
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    `SameSite=${sameSite}`,
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (isHttps) parts.push('Secure');
  return parts.join('; ');
}

function isOriginAllowed(origin: string | null, env: WorkerEnv, requestUrl: URL): boolean {
  if (!origin) return true;
  if (origin === requestUrl.origin) return true;
  const allowed = [env.PUBLIC_ORIGIN, env.ADMIN_ORIGIN]
    .filter((v): v is string => !!v && v.trim().length > 0)
    .flatMap((v) => v.split(','))
    .map((v) => v.trim().replace(/\/$/, ''))
    .filter(Boolean);
  if (allowed.includes(origin)) return true;

  if (env.ALLOW_LOCAL_DEV_ORIGINS === 'true') {
    try {
      const originUrl = new URL(origin);
      if (originUrl.host === requestUrl.host) return true;
    } catch {
      // Ignore malformed origin URL
    }
    if (
      /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin) ||
      /^https:\/\/[a-z0-9.-]+\.run\.app$/i.test(origin) ||
      /^https:\/\/[a-z0-9.-]+\.aistudio\.google\.com$/i.test(origin) ||
      /^https:\/\/[a-z0-9.-]+\.googleusercontent\.com$/i.test(origin)
    ) {
      return true;
    }
  }
  return false;
}

function jsonResponse(
  data: unknown,
  status = 200,
  headers?: HeadersInit,
  cookies?: string[]
): Response {
  const resHeaders = new Headers({
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    ...headers,
  });
  if (cookies) {
    for (const c of cookies) {
      resHeaders.append('Set-Cookie', c);
    }
  }
  return new Response(JSON.stringify(data), { status, headers: resHeaders });
}

function parseJsonBody<T>(request: Request): Promise<T | null> {
  return request.json().catch(() => null) as Promise<T | null>;
}

function detectPlatform(userAgent: string): { label: string; platform: string } {
  if (/iPhone/i.test(userAgent)) return { label: 'iPhone Browser', platform: 'iOS' };
  if (/iPad/i.test(userAgent)) return { label: 'iPad Browser', platform: 'iPadOS' };
  if (/Android/i.test(userAgent)) return { label: 'Android Device', platform: 'Android' };
  if (/Macintosh/i.test(userAgent)) return { label: 'Mac Workstation', platform: 'macOS' };
  if (/Windows/i.test(userAgent)) return { label: 'Windows PC', platform: 'Windows' };
  return { label: 'Web Client', platform: 'Linux/Web' };
}

function generateProductKeyString(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const block = () => {
    const bytes = new Uint8Array(4);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (b) => chars[b % chars.length]).join('');
  };
  return `PMWR-${block()}-${block()}-${block()}`;
}

function isSafeExternalUrl(rawUrl: string): { ok: boolean; reason?: string; scheme?: 'https' | 'happ' } {
  const trimmed = rawUrl.trim();
  if (!trimmed) return { ok: false, reason: 'URL is empty' };
  if (trimmed.startsWith('happ://')) {
    if (trimmed.length < 10 || /\s/.test(trimmed)) {
      return { ok: false, reason: 'Invalid happ:// URI format' };
    }
    return { ok: true, scheme: 'happ' };
  }
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { ok: false, reason: 'Invalid URL syntax' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { ok: false, reason: 'Only https://, http://, or happ:// URLs are permitted' };
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '[::1]' ||
    host === '[::]' ||
    host.startsWith('[::ffff:') ||
    host.startsWith('[fe80:') ||
    host.startsWith('[fc') ||
    host.startsWith('[fd') ||
    host.endsWith('.local') ||
    host.startsWith('10.') ||
    host.startsWith('192.168.') ||
    host.startsWith('169.254.') ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host)
  ) {
    return { ok: false, reason: 'Private or loopback network hosts are blocked' };
  }
  return { ok: true, scheme: 'https' };
}

async function resolveDeviceFromRequest(
  request: Request,
  env: WorkerEnv,
  issueIfMissing: boolean
): Promise<{
  deviceId: string | null;
  rawDeviceToken: string | null;
  newlyIssued: boolean;
  platform: string;
  label: string;
  blocked: boolean;
}> {
  const cookies = parseCookies(request.headers.get('Cookie'));
  const candidateToken =
    request.headers.get('X-Device-Token')?.trim() || cookies['pmwr_device'] || null;
  const ua = request.headers.get('User-Agent') ?? 'Unknown Client';
  const detected = detectPlatform(ua);

  if (candidateToken) {
    const verified = await verifySignedDeviceToken(candidateToken, env.SESSION_SECRET);
    if (verified) {
      const tokenHash = await sha256Hex(candidateToken);
      const row = await env.DB.prepare(
        `SELECT id, status, platform, device_label FROM registered_devices WHERE id = ? AND device_token_hash = ?`
      )
        .bind(verified.deviceId, tokenHash)
        .first<{ id: string; status: string; platform: string; device_label: string }>();

      if (row) {
        await env.DB.prepare(`UPDATE registered_devices SET last_seen_at = ? WHERE id = ?`)
          .bind(new Date().toISOString(), row.id)
          .run();
        return {
          deviceId: row.id,
          rawDeviceToken: candidateToken,
          newlyIssued: false,
          platform: row.platform,
          label: row.device_label,
          blocked: row.status === 'blocked',
        };
      }
    }
  }

  if (!issueIfMissing) {
    return {
      deviceId: null,
      rawDeviceToken: null,
      newlyIssued: false,
      platform: detected.platform,
      label: detected.label,
      blocked: false,
    };
  }

  const deviceId = randomId('dev');
  const signedToken = await signDeviceToken(deviceId, env.SESSION_SECRET);
  const tokenHash = await sha256Hex(signedToken);
  const nowIso = new Date().toISOString();

  await env.DB.prepare(
    `INSERT INTO registered_devices (
      id, device_token_hash, device_label, platform, user_agent, status, first_seen_at, last_seen_at
    ) VALUES (?, ?, ?, ?, ?, 'trusted', ?, ?)`
  )
    .bind(deviceId, tokenHash, detected.label, detected.platform, ua.slice(0, 250), nowIso, nowIso)
    .run();

  return {
    deviceId,
    rawDeviceToken: signedToken,
    newlyIssued: true,
    platform: detected.platform,
    label: detected.label,
    blocked: false,
  };
}

async function authenticateAdmin(
  request: Request,
  env: WorkerEnv
): Promise<AuthenticatedAdmin | null> {
  const cookies = parseCookies(request.headers.get('Cookie'));
  const authHeader = request.headers.get('Authorization');
  const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const rawToken = bearer || cookies['pmwr_admin_session'] || null;
  if (!rawToken) return null;

  const tokenHash = await sha256Hex(rawToken);
  const nowIso = new Date().toISOString();

  const row = await env.DB.prepare(
    `SELECT s.id AS session_id, s.expires_at, a.id, a.username, a.email, a.role_id, a.custom_permissions_json, a.status
     FROM admin_sessions s
     JOIN administrators a ON a.id = s.admin_id
     WHERE s.token_hash = ? AND s.revoked_at IS NULL`
  )
    .bind(tokenHash)
    .first<{
      session_id: string;
      expires_at: string;
      id: string;
      username: string;
      email: string;
      role_id: AdminRoleId;
      custom_permissions_json: string;
      status: 'active' | 'suspended';
    }>();

  if (!row || row.expires_at <= nowIso || row.status !== 'active') {
    return null;
  }

  const permissions = await resolveAdminPermissions(
    env.DB,
    row.role_id,
    row.custom_permissions_json
  );

  return {
    sessionId: row.session_id,
    id: row.id,
    username: row.username,
    email: row.email,
    roleId: row.role_id,
    permissions,
  };
}

async function authenticateUserSession(request: Request, env: WorkerEnv) {
  const cookies = parseCookies(request.headers.get('Cookie'));
  const authHeader = request.headers.get('Authorization');
  const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const rawToken = bearer || cookies['pmwr_user_session'] || null;
  if (!rawToken) return null;

  const tokenHash = await sha256Hex(rawToken);
  const nowIso = new Date().toISOString();

  const session = await env.DB.prepare(
    `SELECT id, user_id, auth_type, product_key_id, universal_code_id, device_id,
            selected_server_id, active_feature_id, created_at, expires_at, revoked_at
     FROM user_sessions
     WHERE token_hash = ? AND revoked_at IS NULL`
  )
    .bind(tokenHash)
    .first<{
      id: string;
      user_id: string;
      auth_type: 'product_key' | 'universal_code';
      product_key_id: string | null;
      universal_code_id: string | null;
      device_id: string;
      selected_server_id: ServerId;
      active_feature_id: FeatureId | null;
      created_at: string;
      expires_at: string;
      revoked_at: string | null;
    }>();

  if (!session || session.expires_at <= nowIso) {
    return null;
  }

  const deviceInfo = await resolveDeviceFromRequest(request, env, false);
  if (!deviceInfo.deviceId || deviceInfo.deviceId !== session.device_id || deviceInfo.blocked) {
    return { invalidReason: 'DEVICE_UNBOUND_OR_BLOCKED' as const };
  }

  if (session.auth_type === 'product_key' && session.product_key_id) {
    const keyRow = await env.DB.prepare(
      `SELECT id, key_code, status, duration_seconds, allowed_servers_json, allowed_features_json,
              bound_device_id, created_at, activated_at, expires_at
       FROM product_keys WHERE id = ?`
    )
      .bind(session.product_key_id)
      .first<{
        id: string;
        key_code: string;
        status: string;
        duration_seconds: number;
        allowed_servers_json: string;
        allowed_features_json: string;
        bound_device_id: string | null;
        created_at: string;
        activated_at: string | null;
        expires_at: string | null;
      }>();

    if (
      !keyRow ||
      keyRow.status !== 'active' ||
      !keyRow.expires_at ||
      keyRow.expires_at <= nowIso ||
      keyRow.bound_device_id !== session.device_id
    ) {
      return { invalidReason: 'CREDENTIAL_INVALID_OR_EXPIRED' as const };
    }

    return {
      session,
      deviceInfo,
      credential: {
        authType: 'product_key' as const,
        id: keyRow.id,
        codeDisplay: keyRow.key_code,
        status: keyRow.status,
        durationSeconds: keyRow.duration_seconds,
        activatedAt: keyRow.activated_at,
        expiresAt: keyRow.expires_at,
        allowedServers: JSON.parse(keyRow.allowed_servers_json) as ServerId[],
        allowedFeatures: JSON.parse(keyRow.allowed_features_json) as FeatureId[],
      },
    };
  }

  if (session.auth_type === 'universal_code' && session.universal_code_id) {
    const uRow = await env.DB.prepare(
      `SELECT id, code, status, duration_seconds, allowed_servers_json, allowed_features_json,
              created_at, activated_at, expires_at
       FROM universal_codes WHERE id = ?`
    )
      .bind(session.universal_code_id)
      .first<{
        id: string;
        code: string;
        status: string;
        duration_seconds: number;
        allowed_servers_json: string;
        allowed_features_json: string;
        created_at: string;
        activated_at: string | null;
        expires_at: string;
      }>();

    if (!uRow || uRow.status !== 'active' || uRow.expires_at <= nowIso) {
      return { invalidReason: 'CREDENTIAL_INVALID_OR_EXPIRED' as const };
    }

    return {
      session,
      deviceInfo,
      credential: {
        authType: 'universal_code' as const,
        id: uRow.id,
        codeDisplay: uRow.code,
        status: uRow.status,
        durationSeconds: uRow.duration_seconds,
        activatedAt: uRow.activated_at ?? uRow.created_at,
        expiresAt: uRow.expires_at,
        allowedServers: JSON.parse(uRow.allowed_servers_json) as ServerId[],
        allowedFeatures: JSON.parse(uRow.allowed_features_json) as FeatureId[],
      },
    };
  }

  return null;
}

export async function handleApiRequest(request: Request, env: WorkerEnv): Promise<Response> {
  const url = new URL(request.url);
  const origin = request.headers.get('Origin');
  const isHttps = url.protocol === 'https:';
  const crossSite = !!origin && origin !== url.origin;

  const corsHeaders: Record<string, string> = {};
  if (origin && isOriginAllowed(origin, env, url)) {
    corsHeaders['Access-Control-Allow-Origin'] = origin;
    corsHeaders['Access-Control-Allow-Credentials'] = 'true';
    corsHeaders['Access-Control-Allow-Headers'] =
      'Content-Type, Authorization, X-Device-Token, X-Bootstrap-Secret';
    corsHeaders['Access-Control-Allow-Methods'] = 'GET, POST, PATCH, DELETE, OPTIONS';
    corsHeaders['Vary'] = 'Origin';
  }

  if (request.method === 'OPTIONS') {
    if (!isOriginAllowed(origin, env, url)) {
      return jsonResponse({ error: 'Origin not allowed' }, 403);
    }
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (
    ['POST', 'PATCH', 'PUT', 'DELETE'].includes(request.method) &&
    origin &&
    !isOriginAllowed(origin, env, url)
  ) {
    return jsonResponse({ error: 'Forbidden origin (CSRF protection)' }, 403, corsHeaders);
  }

  const respond = (data: unknown, status = 200, cookies?: string[]) =>
    jsonResponse(data, status, corsHeaders, cookies);

  if (!env.SESSION_SECRET || env.SESSION_SECRET.length < 16) {
    return respond({ error: 'Server SESSION_SECRET is not configured' }, 500);
  }

  await expireStaleCredentials(env.DB);
  const ipHash = await getClientIpHash(request);
  const pathname = url.pathname;

  // ---------------------------------------------------------------------------
  // 1. HEALTH & PUBLIC STATUS
  // ---------------------------------------------------------------------------
  if (pathname === '/api/health' && request.method === 'GET') {
    return respond({ ok: true, service: 'primewirepro-api', timestamp: new Date().toISOString() });
  }

  if (pathname === '/api/public/status' && request.method === 'GET') {
    const settings = await env.DB.prepare(
      `SELECT website_title, maintenance_mode, maintenance_message, announcement, default_server_id
       FROM website_settings WHERE id = 1`
    ).first<{
      website_title: string;
      maintenance_mode: number;
      maintenance_message: string;
      announcement: string;
      default_server_id: ServerId;
    }>();

    return respond({
      websiteTitle: settings?.website_title ?? 'PRIME WIRE PRO',
      maintenanceMode: settings?.maintenance_mode === 1,
      maintenanceMessage: settings?.maintenance_message ?? '',
      announcement: settings?.announcement ?? '',
      defaultServerId: settings?.default_server_id ?? 'singapore',
    });
  }

  // ---------------------------------------------------------------------------
  // 2. PUBLIC USER AUTHENTICATION (PRODUCT KEY OR UNIVERSAL CODE)
  // ---------------------------------------------------------------------------
  if (pathname === '/api/auth/login' && request.method === 'POST') {
    const rate = await checkRateLimit(env.DB, `user_login:${ipHash}`, 15, 10 * 60_000, 10 * 60_000);
    if (!rate.allowed) {
      return respond(
        { error: `Too many attempts. Try again in ${rate.retryAfterSec}s.` },
        429
      );
    }

    const settings = await env.DB.prepare(
      `SELECT maintenance_mode, maintenance_message, default_server_id FROM website_settings WHERE id = 1`
    ).first<{
      maintenance_mode: number;
      maintenance_message: string;
      default_server_id: ServerId;
    }>();

    if (settings?.maintenance_mode === 1) {
      return respond(
        {
          error: settings.maintenance_message || 'Maintenance mode is active.',
          code: 'MAINTENANCE_MODE',
        },
        503
      );
    }

    const body = await parseJsonBody<{ code?: string; rememberDevice?: boolean }>(request);
    const rawInput = body?.code?.trim().toUpperCase() ?? '';
    const rememberDevice = body?.rememberDevice !== false;

    if (!rawInput || rawInput.length < 4 || rawInput.length > 64) {
      return respond({ error: 'Enter a valid product key or universal code.' }, 400);
    }

    const deviceInfo = await resolveDeviceFromRequest(request, env, true);
    if (!deviceInfo.deviceId || !deviceInfo.rawDeviceToken) {
      return respond({ error: 'Device registration failed.' }, 500);
    }
    if (deviceInfo.blocked) {
      await writeSecurityLog(env.DB, {
        eventType: 'LOGIN_FAILED_DEVICE_BLOCKED',
        actorType: 'anonymous',
        actorId: deviceInfo.deviceId,
        actorLabel: deviceInfo.label,
        resourceType: 'device',
        resourceId: deviceInfo.deviceId,
        result: 'denied',
        details: 'Blocked device attempted login',
        ipHash,
      });
      return respond({ error: 'This device has been blocked by an administrator.' }, 403);
    }

    const deviceCookie = buildCookieHeader(
      'pmwr_device',
      deviceInfo.rawDeviceToken,
      365 * 86400,
      isHttps,
      crossSite
    );

    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();

    // Check Individual Product Key first
    const keyRow = await env.DB.prepare(
      `SELECT * FROM product_keys WHERE key_code = ?`
    )
      .bind(rawInput)
      .first<{
        id: string;
        key_code: string;
        status: string;
        duration_seconds: number;
        custom_expires_at: string | null;
        allowed_servers_json: string;
        allowed_features_json: string;
        bound_device_id: string | null;
        activated_at: string | null;
        expires_at: string | null;
      }>();

    if (keyRow) {
      if (keyRow.status === 'suspended') {
        await writeSecurityLog(env.DB, {
          eventType: 'FAILED_KEY_ACTIVATION',
          actorType: 'anonymous',
          actorId: deviceInfo.deviceId,
          actorLabel: keyRow.key_code,
          resourceType: 'product_key',
          resourceId: keyRow.id,
          result: 'denied',
          details: 'Key is suspended',
          ipHash,
        });
        return respond({ error: 'This product key is suspended.' }, 403, [deviceCookie]);
      }
      if (keyRow.status === 'revoked') {
        await writeSecurityLog(env.DB, {
          eventType: 'FAILED_KEY_ACTIVATION',
          actorType: 'anonymous',
          actorId: deviceInfo.deviceId,
          actorLabel: keyRow.key_code,
          resourceType: 'product_key',
          resourceId: keyRow.id,
          result: 'denied',
          details: 'Key is revoked',
          ipHash,
        });
        return respond({ error: 'This product key has been revoked.' }, 403, [deviceCookie]);
      }
      if (keyRow.status === 'expired' || (keyRow.expires_at && keyRow.expires_at <= nowIso)) {
        await env.DB.prepare(`UPDATE product_keys SET status = 'expired' WHERE id = ?`)
          .bind(keyRow.id)
          .run();
        await writeSecurityLog(env.DB, {
          eventType: 'FAILED_KEY_ACTIVATION',
          actorType: 'anonymous',
          actorId: deviceInfo.deviceId,
          actorLabel: keyRow.key_code,
          resourceType: 'product_key',
          resourceId: keyRow.id,
          result: 'denied',
          details: 'Key expired',
          ipHash,
        });
        return respond({ error: 'This product key has expired.' }, 403, [deviceCookie]);
      }

      // Enforce ONE DEVICE PER KEY PERMANENT BINDING
      if (keyRow.bound_device_id && keyRow.bound_device_id !== deviceInfo.deviceId) {
        await writeSecurityLog(env.DB, {
          eventType: 'UNAUTHORIZED_DEVICE_ACTIVATION',
          actorType: 'anonymous',
          actorId: deviceInfo.deviceId,
          actorLabel: deviceInfo.label,
          resourceType: 'product_key',
          resourceId: keyRow.id,
          result: 'denied',
          details: `Key ${keyRow.key_code} is permanently bound to device ${keyRow.bound_device_id}`,
          ipHash,
        });
        return respond(
          {
            error:
              'This product key is permanently bound to another registered device. Only an administrator can unbind it.',
            code: 'DEVICE_MISMATCH',
          },
          403,
          [deviceCookie]
        );
      }

      let activatedAt = keyRow.activated_at;
      let expiresAt = keyRow.expires_at;

      if (!activatedAt) {
        activatedAt = nowIso;
      }
      if (!expiresAt) {
        expiresAt =
          keyRow.custom_expires_at ??
          new Date(nowMs + keyRow.duration_seconds * 1000).toISOString();
      }

      if (expiresAt <= nowIso) {
        await env.DB.prepare(`UPDATE product_keys SET status = 'expired' WHERE id = ?`)
          .bind(keyRow.id)
          .run();
        return respond({ error: 'This product key has expired.' }, 403, [deviceCookie]);
      }

      if (!keyRow.bound_device_id) {
        // Atomic first-time device binding
        const bindResult = await env.DB.prepare(
          `UPDATE product_keys
           SET bound_device_id = ?, bound_at = ?, activated_at = ?, expires_at = ?
           WHERE id = ? AND bound_device_id IS NULL`
        )
          .bind(deviceInfo.deviceId, nowIso, activatedAt, expiresAt, keyRow.id)
          .run();

        if (!bindResult.meta.changes) {
          return respond({ error: 'Device binding conflict. Please retry.' }, 409, [deviceCookie]);
        }

        await writeSecurityLog(env.DB, {
          eventType: 'DEVICE_BIND',
          actorType: 'user',
          actorId: deviceInfo.deviceId,
          actorLabel: keyRow.key_code,
          resourceType: 'product_key',
          resourceId: keyRow.id,
          result: 'success',
          details: `Key permanently bound to device ${deviceInfo.deviceId} (${deviceInfo.platform})`,
          ipHash,
        });
      } else {
        await env.DB.prepare(
          `UPDATE product_keys SET activated_at = COALESCE(activated_at, ?), expires_at = ? WHERE id = ?`
        )
          .bind(activatedAt, expiresAt, keyRow.id)
          .run();
      }

      // Upsert user record
      let userRow = await env.DB.prepare(
        `SELECT id FROM users WHERE auth_type = 'product_key' AND product_key_id = ?`
      )
        .bind(keyRow.id)
        .first<{ id: string }>();

      if (!userRow) {
        const userId = randomId('usr');
        await env.DB.prepare(
          `INSERT INTO users (id, auth_type, product_key_id, device_id, created_at, last_login_at)
           VALUES (?, 'product_key', ?, ?, ?, ?)`
        )
          .bind(userId, keyRow.id, deviceInfo.deviceId, nowIso, nowIso)
          .run();
        userRow = { id: userId };
      } else {
        await env.DB.prepare(`UPDATE users SET last_login_at = ?, device_id = ? WHERE id = ?`)
          .bind(nowIso, deviceInfo.deviceId, userRow.id)
          .run();
      }

      const allowedServers = JSON.parse(keyRow.allowed_servers_json) as ServerId[];
      const defaultServer = allowedServers.includes(settings?.default_server_id ?? 'singapore')
        ? (settings?.default_server_id ?? 'singapore')
        : allowedServers[0] ?? 'singapore';

      const sessionToken = randomHex(32);
      const tokenHash = await sha256Hex(sessionToken);
      const sessionId = randomId('usess');
      const sessionExpiresAt = rememberDevice
        ? expiresAt
        : new Date(Math.min(new Date(expiresAt).getTime(), nowMs + 12 * 3600_000)).toISOString();

      await env.DB.prepare(
        `INSERT INTO user_sessions (
          id, user_id, auth_type, product_key_id, device_id, token_hash,
          selected_server_id, active_feature_id, created_at, expires_at
        ) VALUES (?, ?, 'product_key', ?, ?, ?, ?, NULL, ?, ?)`
      )
        .bind(
          sessionId,
          userRow.id,
          keyRow.id,
          deviceInfo.deviceId,
          tokenHash,
          defaultServer,
          nowIso,
          sessionExpiresAt
        )
        .run();

      await resetRateLimit(env.DB, `user_login:${ipHash}`);
      await writeSecurityLog(env.DB, {
        eventType: 'USER_LOGIN_SUCCESS',
        actorType: 'user',
        actorId: userRow.id,
        actorLabel: keyRow.key_code,
        resourceType: 'product_key',
        resourceId: keyRow.id,
        result: 'success',
        details: `Signed in on ${deviceInfo.platform}`,
        ipHash,
      });

      const sessionCookie = buildCookieHeader(
        'pmwr_user_session',
        sessionToken,
        Math.max(60, Math.floor((new Date(sessionExpiresAt).getTime() - nowMs) / 1000)),
        isHttps,
        crossSite
      );

      return respond(
        {
          ok: true,
          sessionToken,
          deviceToken: deviceInfo.rawDeviceToken,
          authType: 'product_key',
        },
        200,
        [deviceCookie, sessionCookie]
      );
    }

    // Check Universal Public Code
    const universalRow = await env.DB.prepare(
      `SELECT * FROM universal_codes WHERE code = ?`
    )
      .bind(rawInput)
      .first<{
        id: string;
        code: string;
        status: string;
        duration_seconds: number;
        allowed_servers_json: string;
        allowed_features_json: string;
        created_at: string;
        activated_at: string | null;
        expires_at: string;
      }>();

    if (universalRow) {
      if (universalRow.status === 'suspended') {
        return respond({ error: 'This universal code is suspended.' }, 403, [deviceCookie]);
      }
      if (universalRow.status === 'revoked') {
        return respond({ error: 'This universal code has been revoked.' }, 403, [deviceCookie]);
      }
      if (universalRow.status === 'expired' || universalRow.expires_at <= nowIso) {
        await env.DB.prepare(`UPDATE universal_codes SET status = 'expired' WHERE id = ?`)
          .bind(universalRow.id)
          .run();
        return respond({ error: 'This universal code has expired.' }, 403, [deviceCookie]);
      }

      await env.DB.prepare(
        `UPDATE universal_codes
         SET usage_count = usage_count + 1,
             activated_at = COALESCE(activated_at, ?)
         WHERE id = ?`
      )
        .bind(nowIso, universalRow.id)
        .run();

      const userId = randomId('usr');
      await env.DB.prepare(
        `INSERT INTO users (id, auth_type, universal_code_id, device_id, created_at, last_login_at)
         VALUES (?, 'universal_code', ?, ?, ?, ?)`
      )
        .bind(userId, universalRow.id, deviceInfo.deviceId, nowIso, nowIso)
        .run();

      const allowedServers = JSON.parse(universalRow.allowed_servers_json) as ServerId[];
      const defaultServer = allowedServers.includes(settings?.default_server_id ?? 'singapore')
        ? (settings?.default_server_id ?? 'singapore')
        : allowedServers[0] ?? 'singapore';

      const sessionToken = randomHex(32);
      const tokenHash = await sha256Hex(sessionToken);
      const sessionId = randomId('usess');

      await env.DB.prepare(
        `INSERT INTO user_sessions (
          id, user_id, auth_type, universal_code_id, device_id, token_hash,
          selected_server_id, active_feature_id, created_at, expires_at
        ) VALUES (?, ?, 'universal_code', ?, ?, ?, ?, NULL, ?, ?)`
      )
        .bind(
          sessionId,
          userId,
          universalRow.id,
          deviceInfo.deviceId,
          tokenHash,
          defaultServer,
          nowIso,
          universalRow.expires_at
        )
        .run();

      await resetRateLimit(env.DB, `user_login:${ipHash}`);
      await writeSecurityLog(env.DB, {
        eventType: 'USER_LOGIN_UNIVERSAL',
        actorType: 'user',
        actorId: userId,
        actorLabel: universalRow.code,
        resourceType: 'universal_code',
        resourceId: universalRow.id,
        result: 'success',
        details: `Universal code login on ${deviceInfo.platform}`,
        ipHash,
      });

      const sessionCookie = buildCookieHeader(
        'pmwr_user_session',
        sessionToken,
        Math.max(60, Math.floor((new Date(universalRow.expires_at).getTime() - nowMs) / 1000)),
        isHttps,
        crossSite
      );

      return respond(
        {
          ok: true,
          sessionToken,
          deviceToken: deviceInfo.rawDeviceToken,
          authType: 'universal_code',
        },
        200,
        [deviceCookie, sessionCookie]
      );
    }

    await writeSecurityLog(env.DB, {
      eventType: 'FAILED_KEY_ACTIVATION',
      actorType: 'anonymous',
      actorId: deviceInfo.deviceId,
      actorLabel: PRODUCT_KEY_REGEX.test(rawInput) ? rawInput : 'UNRECOGNIZED_CODE',
      resourceType: 'credential',
      resourceId: 'unknown',
      result: 'denied',
      details: 'Invalid product key or universal code',
      ipHash,
    });

    return respond(
      { error: 'Invalid product key or universal code.' },
      401,
      [deviceCookie]
    );
  }

  if (pathname === '/api/auth/logout' && request.method === 'POST') {
    const cookies = parseCookies(request.headers.get('Cookie'));
    const authHeader = request.headers.get('Authorization');
    const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
    const rawToken = bearer || cookies['pmwr_user_session'] || null;
    if (rawToken) {
      const tokenHash = await sha256Hex(rawToken);
      await env.DB.prepare(`UPDATE user_sessions SET revoked_at = ? WHERE token_hash = ?`)
        .bind(new Date().toISOString(), tokenHash)
        .run();
    }
    const clearCookie = buildCookieHeader('pmwr_user_session', '', 0, isHttps, crossSite);
    return respond({ ok: true }, 200, [clearCookie]);
  }

  // ---------------------------------------------------------------------------
  // 3. AUTHENTICATED USER ROUTES
  // ---------------------------------------------------------------------------
  if (pathname === '/api/user/me' && request.method === 'GET') {
    const settings = await env.DB.prepare(
      `SELECT website_title, maintenance_mode, maintenance_message, announcement FROM website_settings WHERE id = 1`
    ).first<{
      website_title: string;
      maintenance_mode: number;
      maintenance_message: string;
      announcement: string;
    }>();

    if (settings?.maintenance_mode === 1) {
      return respond(
        {
          error: settings.maintenance_message || 'Maintenance mode is active.',
          code: 'MAINTENANCE_MODE',
        },
        503
      );
    }

    const auth = await authenticateUserSession(request, env);
    if (!auth) return respond({ error: 'Unauthorized' }, 401);
    if ('invalidReason' in auth) {
      return respond({ error: 'Session is no longer valid.', code: auth.invalidReason }, 401);
    }

    const serversRes = await env.DB.prepare(
      `SELECT id, name, flag, code, enabled, status, routing_note FROM servers ORDER BY sort_order ASC`
    ).all<{
      id: ServerId;
      name: string;
      flag: string;
      code: string;
      enabled: number;
      status: string;
      routing_note: string;
    }>();

    const featuresRes = await env.DB.prepare(
      `SELECT id, title, description, enabled FROM features`
    ).all<{
      id: FeatureId;
      title: string;
      description: string;
      enabled: number;
    }>();

    return respond({
      session: {
        id: auth.session.id,
        authType: auth.credential.authType,
        selectedServerId: auth.session.selected_server_id,
        activeFeatureId: auth.session.active_feature_id,
        signedInAt: auth.session.created_at,
        expiresAt: auth.credential.expiresAt,
      },
      credential: {
        code: auth.credential.codeDisplay,
        status: auth.credential.status,
        durationSeconds: auth.credential.durationSeconds,
        activatedAt: auth.credential.activatedAt,
        expiresAt: auth.credential.expiresAt,
        allowedServers: auth.credential.allowedServers,
        allowedFeatures: auth.credential.allowedFeatures,
      },
      device: {
        id: auth.deviceInfo.deviceId,
        label: auth.deviceInfo.label,
        platform: auth.deviceInfo.platform,
        permanentBinding: auth.credential.authType === 'product_key',
      },
      servers: serversRes.results.map((s) => ({
        id: s.id,
        name: s.name,
        flag: s.flag,
        code: s.code,
        enabled: s.enabled === 1,
        status: s.status,
        routingNote: s.routing_note,
      })),
      features: featuresRes.results.map((f) => ({
        id: f.id,
        title: f.title,
        description: f.description,
        enabled: f.enabled === 1,
      })),
      settings: {
        websiteTitle: settings?.website_title ?? 'PRIME WIRE PRO',
        announcement: settings?.announcement ?? '',
      },
    });
  }

  if (pathname === '/api/user/preferences' && request.method === 'PATCH') {
    const auth = await authenticateUserSession(request, env);
    if (!auth) return respond({ error: 'Unauthorized' }, 401);
    if ('invalidReason' in auth) return respond({ error: 'Session expired or unbound' }, 401);

    const body = await parseJsonBody<{
      selectedServerId?: ServerId;
      activeFeatureId?: FeatureId | null;
    }>(request);
    if (!body) return respond({ error: 'Invalid JSON body' }, 400);

    let nextServerId = auth.session.selected_server_id;
    let nextFeatureId = auth.session.active_feature_id;

    if (body.selectedServerId !== undefined) {
      if (!VALID_SERVERS.includes(body.selectedServerId)) {
        return respond({ error: 'Invalid server selection' }, 400);
      }
      const srv = await env.DB.prepare(`SELECT enabled, status FROM servers WHERE id = ?`)
        .bind(body.selectedServerId)
        .first<{ enabled: number; status: string }>();
      if (!srv || srv.enabled !== 1 || srv.status === 'maintenance') {
        return respond({ error: 'Selected server is currently disabled or in maintenance.' }, 403);
      }
      if (!auth.credential.allowedServers.includes(body.selectedServerId)) {
        return respond({ error: 'Your code does not permit this server.' }, 403);
      }
      nextServerId = body.selectedServerId;
    }

    if (body.activeFeatureId !== undefined) {
      if (body.activeFeatureId === null) {
        nextFeatureId = null;
      } else {
        if (!VALID_FEATURES.includes(body.activeFeatureId)) {
          return respond({ error: 'Invalid feature selection' }, 400);
        }
        const feat = await env.DB.prepare(`SELECT enabled FROM features WHERE id = ?`)
          .bind(body.activeFeatureId)
          .first<{ enabled: number }>();
        if (!feat || feat.enabled !== 1) {
          return respond({ error: 'This feature is disabled by an administrator.' }, 403);
        }
        if (!auth.credential.allowedFeatures.includes(body.activeFeatureId)) {
          return respond({ error: 'Your code is not authorized for this feature.' }, 403);
        }
        nextFeatureId = body.activeFeatureId;
      }
    }

    await env.DB.prepare(
      `UPDATE user_sessions SET selected_server_id = ?, active_feature_id = ? WHERE id = ?`
    )
      .bind(nextServerId, nextFeatureId, auth.session.id)
      .run();

    return respond({
      ok: true,
      selectedServerId: nextServerId,
      activeFeatureId: nextFeatureId,
    });
  }

  // ---------------------------------------------------------------------------
  // 4. HAPP SUBSCRIPTION RESOLUTION (STRICTLY AUTHORIZED, NEVER EXPOSED TO UNAUTHORIZED)
  // ---------------------------------------------------------------------------
  if (pathname === '/api/subscription/resolve' && request.method === 'POST') {
    const settings = await env.DB.prepare(
      `SELECT maintenance_mode, maintenance_message FROM website_settings WHERE id = 1`
    ).first<{ maintenance_mode: number; maintenance_message: string }>();
    if (settings?.maintenance_mode === 1) {
      return respond({ error: 'SUBSCRIPTION NOT AVAILABLE', reason: 'Maintenance mode active' }, 503);
    }

    const auth = await authenticateUserSession(request, env);
    if (!auth || 'invalidReason' in auth) {
      return respond({ error: 'Unauthorized or expired access' }, 401);
    }

    const body = await parseJsonBody<{ serverId?: ServerId; featureId?: FeatureId | null }>(request);
    const serverId = body?.serverId ?? auth.session.selected_server_id;
    const featureId = body?.featureId ?? auth.session.active_feature_id;

    if (!VALID_SERVERS.includes(serverId)) {
      return respond({ error: 'SUBSCRIPTION NOT AVAILABLE' }, 400);
    }
    if (!featureId || !VALID_FEATURES.includes(featureId)) {
      return respond(
        { error: 'Select AIM POINT or AIM POINT AND MOCO MARK before adding subscription.' },
        400
      );
    }

    const srv = await env.DB.prepare(`SELECT enabled, status FROM servers WHERE id = ?`)
      .bind(serverId)
      .first<{ enabled: number; status: string }>();
    const feat = await env.DB.prepare(`SELECT enabled FROM features WHERE id = ?`)
      .bind(featureId)
      .first<{ enabled: number }>();

    if (
      !srv ||
      srv.enabled !== 1 ||
      srv.status === 'maintenance' ||
      !feat ||
      feat.enabled !== 1 ||
      !auth.credential.allowedServers.includes(serverId) ||
      !auth.credential.allowedFeatures.includes(featureId)
    ) {
      await env.DB.prepare(
        `INSERT INTO subscription_access_records (
          id, user_id, auth_type, credential_id, device_id, server_id, feature_id, status, reason, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'denied', 'Server or feature disabled or unauthorized', ?)`
      )
        .bind(
          randomId('subrec'),
          auth.session.user_id,
          auth.credential.authType,
          auth.credential.id,
          auth.session.device_id,
          serverId,
          featureId,
          new Date().toISOString()
        )
        .run();
      return respond({ error: 'SUBSCRIPTION NOT AVAILABLE' }, 403);
    }

    const subRow = await env.DB.prepare(
      `SELECT url, enabled FROM subscription_urls WHERE server_id = ? AND feature_id = ?`
    )
      .bind(serverId, featureId)
      .first<{ url: string; enabled: number }>();

    if (!subRow || subRow.enabled !== 1 || !subRow.url.trim()) {
      await env.DB.prepare(
        `INSERT INTO subscription_access_records (
          id, user_id, auth_type, credential_id, device_id, server_id, feature_id, status, reason, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'unavailable', 'Subscription URL empty or disabled', ?)`
      )
        .bind(
          randomId('subrec'),
          auth.session.user_id,
          auth.credential.authType,
          auth.credential.id,
          auth.session.device_id,
          serverId,
          featureId,
          new Date().toISOString()
        )
        .run();

      return respond({ error: 'SUBSCRIPTION NOT AVAILABLE', code: 'SUBSCRIPTION_NOT_AVAILABLE' }, 404);
    }

    const rawUrl = subRow.url.trim();
    const isProxiedHttpScheme =
      rawUrl.startsWith('http://') ||
      rawUrl.startsWith('https://') ||
      rawUrl.startsWith('happ://add/http://') ||
      rawUrl.startsWith('happ://add/https://');

    let happDeepLink = rawUrl.startsWith('happ://') ? rawUrl : `happ://add/${rawUrl}`;
    let subscriptionUrl: string | undefined;

    if (isProxiedHttpScheme) {
      const feedToken = randomHex(24);
      const feedTokenHash = await sha256Hex(feedToken);
      const tokenId = randomId('subtok');
      const nowIso = new Date().toISOString();

      await env.DB.prepare(
        `INSERT INTO subscription_tokens (
          id, token_hash, auth_type, credential_id, device_id, server_id, feature_id,
          created_at, expires_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          tokenId,
          feedTokenHash,
          auth.credential.authType,
          auth.credential.id,
          auth.session.device_id,
          serverId,
          featureId,
          nowIso,
          auth.credential.expiresAt
        )
        .run();

      subscriptionUrl = `${url.origin}/api/sub/${feedToken}`;
      happDeepLink = `happ://add/${subscriptionUrl}`;
    }

    await env.DB.prepare(
      `INSERT INTO subscription_access_records (
        id, user_id, auth_type, credential_id, device_id, server_id, feature_id, status, reason, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'granted', 'Authorized code-bound Happ import triggered', ?)`
    )
      .bind(
        randomId('subrec'),
        auth.session.user_id,
        auth.credential.authType,
        auth.credential.id,
        auth.session.device_id,
        serverId,
        featureId,
        new Date().toISOString()
      )
      .run();

    return respond({
      ok: true,
      happDeepLink,
      subscriptionUrl,
      expiresAt: auth.credential.expiresAt,
      serverId,
      featureId,
    });
  }

  // ---------------------------------------------------------------------------
  // 4B. CODE-BOUND SUBSCRIPTION FEED PROXY (/api/sub/:token)
  // Enforces live credential status & exact code expiration (e.g. 1 hour -> stops)
  // ---------------------------------------------------------------------------
  const subFeedMatch = pathname.match(/^\/api\/sub\/([a-f0-9]{32,96})$/i);
  if (subFeedMatch && (request.method === 'GET' || request.method === 'HEAD')) {
    const rawFeedToken = subFeedMatch[1].toLowerCase();
    const tokenHash = await sha256Hex(rawFeedToken);
    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();

    const expiredResponse = (reason: string, status = 403) =>
      new Response(request.method === 'HEAD' ? null : reason, {
        status,
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Cache-Control': 'no-store, no-cache, must-revalidate',
          'Subscription-Userinfo': `upload=0; download=0; total=1; expire=${Math.floor(nowMs / 1000)}`,
          'X-Robots-Tag': 'noindex',
        },
      });

    const settings = await env.DB.prepare(
      `SELECT maintenance_mode, maintenance_message FROM website_settings WHERE id = 1`
    ).first<{ maintenance_mode: number; maintenance_message: string }>();

    if (settings?.maintenance_mode === 1) {
      return expiredResponse(settings.maintenance_message || 'Maintenance mode active.', 503);
    }

    const tokenRow = await env.DB.prepare(
      `SELECT id, auth_type, credential_id, device_id, server_id, feature_id, expires_at, revoked_at
       FROM subscription_tokens WHERE token_hash = ?`
    )
      .bind(tokenHash)
      .first<{
        id: string;
        auth_type: 'product_key' | 'universal_code';
        credential_id: string;
        device_id: string;
        server_id: ServerId;
        feature_id: FeatureId;
        expires_at: string;
        revoked_at: string | null;
      }>();

    if (!tokenRow || tokenRow.revoked_at || tokenRow.expires_at <= nowIso) {
      return expiredResponse('Subscription link has expired or been revoked.');
    }

    let allowedServers: ServerId[] = [];
    let allowedFeatures: FeatureId[] = [];
    let credentialExpiresAt = tokenRow.expires_at;

    if (tokenRow.auth_type === 'product_key') {
      const keyRow = await env.DB.prepare(
        `SELECT status, bound_device_id, expires_at, allowed_servers_json, allowed_features_json
         FROM product_keys WHERE id = ?`
      )
        .bind(tokenRow.credential_id)
        .first<{
          status: string;
          bound_device_id: string | null;
          expires_at: string | null;
          allowed_servers_json: string;
          allowed_features_json: string;
        }>();

      const devRow = await env.DB.prepare(
        `SELECT status FROM registered_devices WHERE id = ?`
      )
        .bind(tokenRow.device_id)
        .first<{ status: string }>();

      if (
        !keyRow ||
        keyRow.status !== 'active' ||
        !keyRow.expires_at ||
        keyRow.expires_at <= nowIso ||
        keyRow.bound_device_id !== tokenRow.device_id ||
        devRow?.status === 'blocked'
      ) {
        await env.DB.prepare(`UPDATE subscription_tokens SET revoked_at = ? WHERE id = ?`)
          .bind(nowIso, tokenRow.id)
          .run();
        return expiredResponse('Product key has expired, been suspended, or device was unbound.');
      }

      credentialExpiresAt = keyRow.expires_at;
      allowedServers = JSON.parse(keyRow.allowed_servers_json) as ServerId[];
      allowedFeatures = JSON.parse(keyRow.allowed_features_json) as FeatureId[];
    } else {
      const uRow = await env.DB.prepare(
        `SELECT status, expires_at, allowed_servers_json, allowed_features_json
         FROM universal_codes WHERE id = ?`
      )
        .bind(tokenRow.credential_id)
        .first<{
          status: string;
          expires_at: string;
          allowed_servers_json: string;
          allowed_features_json: string;
        }>();

      if (!uRow || uRow.status !== 'active' || uRow.expires_at <= nowIso) {
        await env.DB.prepare(`UPDATE subscription_tokens SET revoked_at = ? WHERE id = ?`)
          .bind(nowIso, tokenRow.id)
          .run();
        return expiredResponse('Universal code has expired or been suspended.');
      }

      credentialExpiresAt = uRow.expires_at;
      allowedServers = JSON.parse(uRow.allowed_servers_json) as ServerId[];
      allowedFeatures = JSON.parse(uRow.allowed_features_json) as FeatureId[];
    }

    const srv = await env.DB.prepare(`SELECT enabled, status FROM servers WHERE id = ?`)
      .bind(tokenRow.server_id)
      .first<{ enabled: number; status: string }>();
    const feat = await env.DB.prepare(`SELECT enabled FROM features WHERE id = ?`)
      .bind(tokenRow.feature_id)
      .first<{ enabled: number }>();

    if (
      !srv ||
      srv.enabled !== 1 ||
      srv.status === 'maintenance' ||
      !feat ||
      feat.enabled !== 1 ||
      !allowedServers.includes(tokenRow.server_id) ||
      !allowedFeatures.includes(tokenRow.feature_id)
    ) {
      return expiredResponse('Selected server or feature is disabled.');
    }

    const subRow = await env.DB.prepare(
      `SELECT url, enabled FROM subscription_urls WHERE server_id = ? AND feature_id = ?`
    )
      .bind(tokenRow.server_id, tokenRow.feature_id)
      .first<{ url: string; enabled: number }>();

    if (!subRow || subRow.enabled !== 1 || !subRow.url.trim()) {
      return expiredResponse('SUBSCRIPTION NOT AVAILABLE', 404);
    }

    const storedUrl = subRow.url.trim();
    const targetUrl = storedUrl.startsWith('happ://add/')
      ? storedUrl.slice('happ://add/'.length).trim()
      : storedUrl;

    const urlCheck = isSafeExternalUrl(targetUrl);
    if (!urlCheck.ok || urlCheck.scheme !== 'https') {
      return expiredResponse('SUBSCRIPTION NOT AVAILABLE', 404);
    }

    await env.DB.prepare(
      `UPDATE subscription_tokens SET last_fetched_at = ?, fetch_count = fetch_count + 1 WHERE id = ?`
    )
      .bind(nowIso, tokenRow.id)
      .run();

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10_000);
      const upstreamRes = await fetch(targetUrl, {
        method: request.method,
        headers: {
          'User-Agent': request.headers.get('User-Agent') || 'Happ/1.0',
          Accept: request.headers.get('Accept') || '*/*',
        },
        signal: controller.signal,
      });
      clearTimeout(timer);

      if (!upstreamRes.ok) {
        return expiredResponse(`Upstream subscription unavailable (${upstreamRes.status}).`, 502);
      }

      const outHeaders = new Headers({
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Content-Type': upstreamRes.headers.get('Content-Type') || 'text/plain; charset=utf-8',
      });

      for (const hName of [
        'Profile-Title',
        'Profile-Update-Interval',
        'Support-Url',
        'Profile-Web-Page-Url',
        'Content-Disposition',
      ]) {
        const val = upstreamRes.headers.get(hName);
        if (val) outHeaders.set(hName, val);
      }
      if (!outHeaders.has('Profile-Update-Interval')) {
        outHeaders.set('Profile-Update-Interval', '1');
      }

      const codeExpireSec = Math.floor(new Date(credentialExpiresAt).getTime() / 1000);
      const upstreamUserInfo = upstreamRes.headers.get('Subscription-Userinfo');
      if (upstreamUserInfo) {
        const cleaned = upstreamUserInfo.replace(/expire=\d+/i, `expire=${codeExpireSec}`);
        outHeaders.set(
          'Subscription-Userinfo',
          /expire=/i.test(upstreamUserInfo) ? cleaned : `${cleaned}; expire=${codeExpireSec}`
        );
      } else {
        outHeaders.set(
          'Subscription-Userinfo',
          `upload=0; download=0; total=0; expire=${codeExpireSec}`
        );
      }

      if (request.method === 'HEAD') {
        return new Response(null, { status: 200, headers: outHeaders });
      }
      const bodyBuf = await upstreamRes.arrayBuffer();
      return new Response(bodyBuf, { status: 200, headers: outHeaders });
    } catch {
      return expiredResponse('Unable to reach upstream subscription endpoint.', 502);
    }
  }

  // ---------------------------------------------------------------------------
  // 5. ADMIN BOOTSTRAP & AUTHENTICATION
  // ---------------------------------------------------------------------------
  if (pathname === '/api/admin/bootstrap-status' && request.method === 'GET') {
    const countRow = await env.DB.prepare(`SELECT COUNT(*) AS cnt FROM administrators`).first<{
      cnt: number;
    }>();
    return respond({ needsBootstrap: (countRow?.cnt ?? 0) === 0 });
  }

  if (pathname === '/api/admin/bootstrap' && request.method === 'POST') {
    const countRow = await env.DB.prepare(`SELECT COUNT(*) AS cnt FROM administrators`).first<{
      cnt: number;
    }>();
    if ((countRow?.cnt ?? 0) > 0) {
      return respond({ error: 'Administrator accounts already initialized.' }, 403);
    }

    if (!env.BOOTSTRAP_SETUP_SECRET) {
      return respond({ error: 'BOOTSTRAP_SETUP_SECRET is not configured on the server.' }, 500);
    }

    const body = await parseJsonBody<{
      setupSecret?: string;
      username?: string;
      email?: string;
      password?: string;
    }>(request);

    const providedSecret = (
      request.headers.get('X-Bootstrap-Secret') ??
      body?.setupSecret ??
      ''
    ).trim();
    if (!providedSecret || !timingSafeEqualStr(providedSecret, env.BOOTSTRAP_SETUP_SECRET.trim())) {
      return respond({ error: 'Invalid bootstrap setup secret.' }, 403);
    }

    const username = body?.username?.trim() ?? '';
    const email = body?.email?.trim().toLowerCase() ?? '';
    const password = body?.password ?? '';

    if (username.length < 3 || !email.includes('@') || password.length < 10) {
      return respond(
        { error: 'Provide a valid username (min 3 chars), email, and strong password (min 10 chars).' },
        400
      );
    }

    const { hashHex, saltHex } = await hashPassword(password);
    const adminId = randomId('adm');
    const nowIso = new Date().toISOString();

    await env.DB.prepare(
      `INSERT INTO administrators (
        id, username, email, password_hash, password_salt, role_id, custom_permissions_json, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'SUPER_ADMIN', '[]', 'active', ?, ?)`
    )
      .bind(adminId, username, email, hashHex, saltHex, nowIso, nowIso)
      .run();

    await writeSecurityLog(env.DB, {
      eventType: 'ADMIN_CREATED',
      actorType: 'system',
      actorId: 'bootstrap',
      actorLabel: username,
      resourceType: 'administrator',
      resourceId: adminId,
      result: 'success',
      details: 'Initial SUPER_ADMIN created',
      ipHash,
    });

    return respond({ ok: true, adminId, username, roleId: 'SUPER_ADMIN' }, 201);
  }

  if (pathname === '/api/admin/login' && request.method === 'POST') {
    const rate = await checkRateLimit(env.DB, `admin_login:${ipHash}`, 8, 15 * 60_000, 15 * 60_000);
    if (!rate.allowed) {
      return respond(
        { error: `Too many login attempts. Retry in ${rate.retryAfterSec}s.` },
        429
      );
    }

    const body = await parseJsonBody<{ email?: string; identifier?: string; password?: string }>(
      request
    );
    const email = (body?.email ?? body?.identifier ?? '').trim().toLowerCase();
    const password = body?.password ?? '';

    if (!email || !email.includes('@') || !password) {
      return respond({ error: 'Valid Gmail/email address and password are required.' }, 400);
    }

    let admin = await env.DB.prepare(`SELECT * FROM administrators WHERE lower(email) = ?`)
      .bind(email)
      .first<AdminRecord>();

    if (!admin) {
      const countRow = await env.DB.prepare(`SELECT COUNT(*) AS cnt FROM administrators`).first<{
        cnt: number;
      }>();

      if ((countRow?.cnt ?? 0) === 0) {
        const envEmail = env.BOOTSTRAP_ADMIN_EMAIL?.trim().toLowerCase();
        const envPass = env.BOOTSTRAP_ADMIN_PASSWORD?.trim() ? env.BOOTSTRAP_ADMIN_PASSWORD : undefined;
        const hasFullEnvBootstrap = Boolean(envEmail && envPass);
        const matchesEnvBootstrap =
          hasFullEnvBootstrap &&
          email === envEmail &&
          timingSafeEqualStr(password, envPass!);
        const allowedLocalFirstAdmin = env.ALLOW_LOCAL_DEV_ORIGINS === 'true' && !hasFullEnvBootstrap;

        if (matchesEnvBootstrap || allowedLocalFirstAdmin) {
          if (password.length < 8) {
            return respond(
              { error: 'Password must be at least 8 characters for initial SUPER ADMIN setup.' },
              400
            );
          }

          const { hashHex, saltHex } = await hashPassword(password);
          const adminId = randomId('adm');
          const nowIso = new Date().toISOString();
          const usernameBase =
            env.BOOTSTRAP_ADMIN_USERNAME?.trim() ||
            email.split('@')[0].replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) ||
            'primeadmin';

          await env.DB.prepare(
            `INSERT INTO administrators (
              id, username, email, password_hash, password_salt, role_id, custom_permissions_json, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, 'SUPER_ADMIN', '[]', 'active', ?, ?)`
          )
            .bind(adminId, usernameBase, email, hashHex, saltHex, nowIso, nowIso)
            .run();

          await writeSecurityLog(env.DB, {
            eventType: 'ADMIN_CREATED',
            actorType: 'system',
            actorId: 'bootstrap',
            actorLabel: email,
            resourceType: 'administrator',
            resourceId: adminId,
            result: 'success',
            details: 'Initial SUPER_ADMIN created via email login',
            ipHash,
          });

          admin = await env.DB.prepare(`SELECT * FROM administrators WHERE id = ?`)
            .bind(adminId)
            .first<AdminRecord>();
        }
      }
    }

    if (!admin) {
      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_LOGIN_FAILED',
        actorType: 'anonymous',
        actorId: 'unknown',
        actorLabel: email,
        resourceType: 'admin_session',
        resourceId: 'none',
        result: 'denied',
        details: 'Unknown admin email',
        ipHash,
      });
      return respond({ error: 'Invalid email or password.' }, 401);
    }

    if (admin.status !== 'active') {
      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_LOGIN_FAILED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.email,
        resourceType: 'administrator',
        resourceId: admin.id,
        result: 'denied',
        details: 'Suspended administrator attempted login',
        ipHash,
      });
      return respond({ error: 'Administrator account is suspended.' }, 403);
    }

    const valid = await verifyPassword(password, admin.password_hash, admin.password_salt);
    if (!valid) {
      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_LOGIN_FAILED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.email,
        resourceType: 'admin_session',
        resourceId: admin.id,
        result: 'denied',
        details: 'Incorrect password',
        ipHash,
      });
      return respond({ error: 'Invalid email or password.' }, 401);
    }

    await resetRateLimit(env.DB, `admin_login:${ipHash}`);
    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();
    const sessionToken = randomHex(32);
    const tokenHash = await sha256Hex(sessionToken);
    const sessionId = randomId('asess');
    const expiresAt = new Date(nowMs + 12 * 3600_000).toISOString();

    await env.DB.prepare(
      `INSERT INTO admin_sessions (id, admin_id, token_hash, ip_hash, user_agent, created_at, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        sessionId,
        admin.id,
        tokenHash,
        ipHash,
        (request.headers.get('User-Agent') ?? '').slice(0, 200),
        nowIso,
        expiresAt
      )
      .run();

    await env.DB.prepare(`UPDATE administrators SET last_login_at = ? WHERE id = ?`)
      .bind(nowIso, admin.id)
      .run();

    await writeSecurityLog(env.DB, {
      eventType: 'ADMIN_LOGIN_SUCCESS',
      actorType: 'admin',
      actorId: admin.id,
      actorLabel: admin.username,
      resourceType: 'admin_session',
      resourceId: sessionId,
      result: 'success',
      details: `Role ${admin.role_id} authenticated`,
      ipHash,
    });

    const adminCookie = buildCookieHeader(
      'pmwr_admin_session',
      sessionToken,
      12 * 3600,
      isHttps,
      crossSite
    );

    return respond(
      {
        ok: true,
        adminToken: sessionToken,
        admin: {
          id: admin.id,
          username: admin.username,
          email: admin.email,
          roleId: admin.role_id,
        },
      },
      200,
      [adminCookie]
    );
  }

  if (pathname === '/api/admin/logout' && request.method === 'POST') {
    const admin = await authenticateAdmin(request, env);
    const cookies = parseCookies(request.headers.get('Cookie'));
    const authHeader = request.headers.get('Authorization');
    const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
    const rawToken = bearer || cookies['pmwr_admin_session'] || null;
    if (rawToken) {
      const tokenHash = await sha256Hex(rawToken);
      await env.DB.prepare(`UPDATE admin_sessions SET revoked_at = ? WHERE token_hash = ?`)
        .bind(new Date().toISOString(), tokenHash)
        .run();
    }
    if (admin) {
      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_LOGOUT',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'admin_session',
        resourceId: admin.sessionId,
        result: 'success',
        ipHash,
      });
    }
    return respond({ ok: true }, 200, [
      buildCookieHeader('pmwr_admin_session', '', 0, isHttps, crossSite),
    ]);
  }

  // ---------------------------------------------------------------------------
  // 6. PROTECTED ADMIN ROUTES (ALL REQUIRE SERVER-SIDE AUTH + RBAC)
  // ---------------------------------------------------------------------------
  if (pathname.startsWith('/api/admin/')) {
    const admin = await authenticateAdmin(request, env);
    if (!admin) {
      return respond({ error: 'Administrator authentication required.' }, 401);
    }

    const requirePerm = (perm: string): Response | null => {
      if (!hasPermission(admin, perm)) {
        return respond({ error: `Missing required permission: ${perm}` }, 403);
      }
      return null;
    };

    if (pathname === '/api/admin/me' && request.method === 'GET') {
      const settings = await env.DB.prepare(`SELECT * FROM website_settings WHERE id = 1`).first();
      return respond({ admin, settings });
    }

    if (pathname === '/api/admin/overview' && request.method === 'GET') {
      const denied = requirePerm('dashboard.view');
      if (denied) return denied;

      const keyCounts = await env.DB.prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active,
          SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) AS expired,
          SUM(CASE WHEN status = 'revoked' THEN 1 ELSE 0 END) AS revoked,
          SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended
         FROM product_keys`
      ).first<Record<string, number>>();

      const universalCount = await env.DB.prepare(
        `SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active FROM universal_codes`
      ).first<Record<string, number>>();

      const deviceCount = await env.DB.prepare(
        `SELECT COUNT(*) AS total FROM registered_devices`
      ).first<{ total: number }>();

      const activeSessions = await env.DB.prepare(
        `SELECT COUNT(*) AS total FROM user_sessions WHERE revoked_at IS NULL AND expires_at > ?`
      )
        .bind(new Date().toISOString())
        .first<{ total: number }>();

      const recentKeys = await env.DB.prepare(
        `SELECT id, key_code, status, duration_seconds, bound_device_id, created_at, activated_at, expires_at
         FROM product_keys ORDER BY created_at DESC LIMIT 6`
      ).all();

      const recentLogs = await env.DB.prepare(
        `SELECT * FROM security_logs ORDER BY timestamp DESC LIMIT 8`
      ).all();

      const serverAccess = await env.DB.prepare(
        `SELECT s.id, s.name, s.flag, COUNT(r.id) AS access_count
         FROM servers s
         LEFT JOIN subscription_access_records r ON r.server_id = s.id
         GROUP BY s.id ORDER BY s.sort_order ASC`
      ).all();

      return respond({
        stats: {
          totalKeys: keyCounts?.total ?? 0,
          activeKeys: keyCounts?.active ?? 0,
          expiredKeys: keyCounts?.expired ?? 0,
          revokedKeys: keyCounts?.revoked ?? 0,
          suspendedKeys: keyCounts?.suspended ?? 0,
          totalUniversalCodes: universalCount?.total ?? 0,
          activeUniversalCodes: universalCount?.active ?? 0,
          registeredDevices: deviceCount?.total ?? 0,
          activeUserSessions: activeSessions?.total ?? 0,
        },
        recentKeys: recentKeys.results,
        recentLogs: recentLogs.results,
        serverAccess: serverAccess.results,
      });
    }

    // --- PRODUCT KEYS CRUD + DEVICE UNBIND ---
    if (pathname === '/api/admin/keys' && request.method === 'GET') {
      const denied = requirePerm('keys.view');
      if (denied) return denied;

      const status = url.searchParams.get('status');
      const search = url.searchParams.get('search')?.trim();
      let sql = `SELECT pk.*, rd.device_label, rd.platform AS device_platform, rd.status AS device_status
                 FROM product_keys pk
                 LEFT JOIN registered_devices rd ON rd.id = pk.bound_device_id
                 WHERE 1=1`;
      const binds: unknown[] = [];

      if (status && status !== 'all') {
        sql += ` AND pk.status = ?`;
        binds.push(status);
      }
      if (search) {
        sql += ` AND (pk.key_code LIKE ? OR pk.notes LIKE ?)`;
        binds.push(`%${search}%`, `%${search}%`);
      }
      sql += ` ORDER BY pk.created_at DESC`;

      const rows = await env.DB.prepare(sql).bind(...binds).all();
      return respond({ keys: rows.results });
    }

    if (pathname === '/api/admin/keys' && request.method === 'POST') {
      const denied = requirePerm('keys.manage');
      if (denied) return denied;

      const body = await parseJsonBody<{
        count?: number;
        customKey?: string;
        durationSeconds?: number;
        customExpiresAt?: string | null;
        allowedServers?: ServerId[];
        allowedFeatures?: FeatureId[];
        notes?: string;
      }>(request);

      const count = Math.min(25, Math.max(1, Number(body?.count ?? 1)));
      const durationSeconds = Math.max(60, Number(body?.durationSeconds ?? 30 * 86400));
      const customExpiresAt = body?.customExpiresAt?.trim() || null;
      const allowedServers = (body?.allowedServers ?? VALID_SERVERS).filter((s) =>
        VALID_SERVERS.includes(s)
      );
      const allowedFeatures = (body?.allowedFeatures ?? VALID_FEATURES).filter((f) =>
        VALID_FEATURES.includes(f)
      );
      if (allowedServers.length === 0 || allowedFeatures.length === 0) {
        return respond({ error: 'Select at least one server and one feature.' }, 400);
      }

      const nowIso = new Date().toISOString();
      const created: unknown[] = [];

      for (let i = 0; i < count; i++) {
        let code = generateProductKeyString();
        if (i === 0 && count === 1 && body?.customKey) {
          const candidate = body.customKey.trim().toUpperCase();
          if (!PRODUCT_KEY_REGEX.test(candidate)) {
            return respond({ error: 'Custom key must match PMWR-XXXX-XXXX-XXXX.' }, 400);
          }
          code = candidate;
        }
        const keyId = randomId('key');
        await env.DB.prepare(
          `INSERT INTO product_keys (
            id, key_code, status, duration_seconds, custom_expires_at,
            allowed_servers_json, allowed_features_json, created_by_admin_id, created_at, expires_at, notes
          ) VALUES (?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            keyId,
            code,
            durationSeconds,
            customExpiresAt,
            JSON.stringify(allowedServers),
            JSON.stringify(allowedFeatures),
            admin.id,
            nowIso,
            customExpiresAt,
            body?.notes?.trim() ?? ''
          )
          .run();

        created.push({ id: keyId, key_code: code });
        await writeSecurityLog(env.DB, {
          eventType: 'KEY_CREATED',
          actorType: 'admin',
          actorId: admin.id,
          actorLabel: admin.username,
          resourceType: 'product_key',
          resourceId: keyId,
          result: 'success',
          details: `Created product key ${code}`,
          ipHash,
        });
      }

      return respond({ ok: true, created }, 201);
    }

    const keyHistoryMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)\/history$/);
    if (keyHistoryMatch && request.method === 'GET') {
      const denied = requirePerm('keys.view');
      if (denied) return denied;
      const keyId = keyHistoryMatch[1];
      const records = await env.DB.prepare(
        `SELECT * FROM subscription_access_records WHERE credential_id = ? ORDER BY created_at DESC LIMIT 30`
      )
        .bind(keyId)
        .all();
      return respond({ history: records.results });
    }

    const keyStatusMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)\/status$/);
    if (keyStatusMatch && request.method === 'POST') {
      const denied = requirePerm('keys.manage');
      if (denied) return denied;
      const keyId = keyStatusMatch[1];
      const body = await parseJsonBody<{ status?: string }>(request);
      const status = body?.status;
      if (!status || !['active', 'suspended', 'revoked'].includes(status)) {
        return respond({ error: 'Invalid key status.' }, 400);
      }

      const existing = await env.DB.prepare(`SELECT key_code FROM product_keys WHERE id = ?`)
        .bind(keyId)
        .first<{ key_code: string }>();
      if (!existing) return respond({ error: 'Key not found' }, 404);

      await env.DB.prepare(`UPDATE product_keys SET status = ? WHERE id = ?`)
        .bind(status, keyId)
        .run();

      if (status !== 'active') {
        const revIso = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE user_sessions SET revoked_at = ? WHERE product_key_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, keyId)
          .run();
        await env.DB.prepare(
          `UPDATE subscription_tokens SET revoked_at = ? WHERE credential_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, keyId)
          .run();
      }

      const eventType =
        status === 'suspended'
          ? 'KEY_SUSPENDED'
          : status === 'revoked'
          ? 'KEY_REVOKED'
          : 'KEY_REACTIVATED';

      await writeSecurityLog(env.DB, {
        eventType,
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'product_key',
        resourceId: keyId,
        result: 'success',
        details: `Key ${existing.key_code} status set to ${status}`,
        ipHash,
      });

      return respond({ ok: true });
    }

    const keyUnbindMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)\/unbind$/);
    if (keyUnbindMatch && request.method === 'POST') {
      const denied = requirePerm('devices.unbind');
      if (denied) return denied;
      const keyId = keyUnbindMatch[1];

      const existing = await env.DB.prepare(
        `SELECT key_code, bound_device_id FROM product_keys WHERE id = ?`
      )
        .bind(keyId)
        .first<{ key_code: string; bound_device_id: string | null }>();
      if (!existing) return respond({ error: 'Key not found' }, 404);

      await env.DB.prepare(
        `UPDATE product_keys SET bound_device_id = NULL, bound_at = NULL WHERE id = ?`
      )
        .bind(keyId)
        .run();

      const revIso = new Date().toISOString();
      await env.DB.prepare(
        `UPDATE user_sessions SET revoked_at = ? WHERE product_key_id = ? AND revoked_at IS NULL`
      )
        .bind(revIso, keyId)
        .run();

      await env.DB.prepare(
        `UPDATE subscription_tokens SET revoked_at = ? WHERE credential_id = ? AND revoked_at IS NULL`
      )
        .bind(revIso, keyId)
        .run();

      await writeSecurityLog(env.DB, {
        eventType: 'DEVICE_UNBIND',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'product_key',
        resourceId: keyId,
        result: 'success',
        details: `Manually unbound device ${existing.bound_device_id ?? 'none'} from ${existing.key_code}`,
        ipHash,
      });

      return respond({ ok: true });
    }

    const keyDeleteMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)$/);
    if (keyDeleteMatch && request.method === 'DELETE') {
      const denied = requirePerm('keys.manage');
      if (denied) return denied;
      const keyId = keyDeleteMatch[1];
      const existing = await env.DB.prepare(`SELECT key_code FROM product_keys WHERE id = ?`)
        .bind(keyId)
        .first<{ key_code: string }>();
      if (!existing) return respond({ error: 'Key not found' }, 404);

      await env.DB.prepare(
        `UPDATE subscription_tokens SET revoked_at = ? WHERE credential_id = ? AND revoked_at IS NULL`
      )
        .bind(new Date().toISOString(), keyId)
        .run();
      await env.DB.prepare(`DELETE FROM product_keys WHERE id = ?`).bind(keyId).run();
      await writeSecurityLog(env.DB, {
        eventType: 'KEY_DELETED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'product_key',
        resourceId: keyId,
        result: 'success',
        details: `Deleted product key ${existing.key_code}`,
        ipHash,
      });
      return respond({ ok: true });
    }

    // --- UNIVERSAL PUBLIC CODES ---
    if (pathname === '/api/admin/universal-codes' && request.method === 'GET') {
      const denied = requirePerm('universal.view');
      if (denied) return denied;
      const rows = await env.DB.prepare(
        `SELECT * FROM universal_codes ORDER BY created_at DESC`
      ).all();
      return respond({ codes: rows.results });
    }

    if (pathname === '/api/admin/universal-codes' && request.method === 'POST') {
      const denied = requirePerm('universal.manage');
      if (denied) return denied;

      const body = await parseJsonBody<{
        code?: string;
        durationSeconds?: number;
        customExpiresAt?: string | null;
        allowedServers?: ServerId[];
        allowedFeatures?: FeatureId[];
        notes?: string;
      }>(request);

      const code = body?.code?.trim().toUpperCase() ?? '';
      if (!/^[A-Z0-9_-]{4,40}$/.test(code)) {
        return respond({ error: 'Code must be 4–40 uppercase letters, digits, - or _.' }, 400);
      }
      const durationSeconds = Math.max(60, Number(body?.durationSeconds ?? 24 * 3600));
      const nowMs = Date.now();
      const nowIso = new Date(nowMs).toISOString();
      const expiresAt =
        body?.customExpiresAt?.trim() ||
        new Date(nowMs + durationSeconds * 1000).toISOString();

      const allowedServers = (body?.allowedServers ?? VALID_SERVERS).filter((s) =>
        VALID_SERVERS.includes(s)
      );
      const allowedFeatures = (body?.allowedFeatures ?? VALID_FEATURES).filter((f) =>
        VALID_FEATURES.includes(f)
      );

      const id = randomId('ucode');
      try {
        await env.DB.prepare(
          `INSERT INTO universal_codes (
            id, code, status, duration_seconds, custom_expires_at, allowed_servers_json,
            allowed_features_json, created_by_admin_id, created_at, expires_at, notes
          ) VALUES (?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            id,
            code,
            durationSeconds,
            body?.customExpiresAt?.trim() || null,
            JSON.stringify(allowedServers),
            JSON.stringify(allowedFeatures),
            admin.id,
            nowIso,
            expiresAt,
            body?.notes?.trim() ?? ''
          )
          .run();
      } catch {
        return respond({ error: 'Universal code already exists.' }, 409);
      }

      await writeSecurityLog(env.DB, {
        eventType: 'UNIVERSAL_CODE_CREATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'universal_code',
        resourceId: id,
        result: 'success',
        details: `Created universal code ${code}`,
        ipHash,
      });

      return respond({ ok: true, id, code }, 201);
    }

    const uPatchMatch = pathname.match(/^\/api\/admin\/universal-codes\/([^/]+)$/);
    if (uPatchMatch && request.method === 'PATCH') {
      const denied = requirePerm('universal.manage');
      if (denied) return denied;
      const id = uPatchMatch[1];
      const body = await parseJsonBody<{
        code?: string;
        durationSeconds?: number;
        expiresAt?: string;
        status?: string;
        allowedServers?: ServerId[];
        allowedFeatures?: FeatureId[];
        notes?: string;
      }>(request);

      const existing = await env.DB.prepare(`SELECT * FROM universal_codes WHERE id = ?`)
        .bind(id)
        .first<{ code: string; status: string }>();
      if (!existing) return respond({ error: 'Universal code not found' }, 404);

      const nextCode = body?.code ? body.code.trim().toUpperCase() : existing.code;
      const nextStatus =
        body?.status && ['active', 'suspended', 'revoked'].includes(body.status)
          ? body.status
          : existing.status;

      if (body?.expiresAt) {
        await env.DB.prepare(
          `UPDATE universal_codes SET code = ?, status = ?, expires_at = ?, notes = COALESCE(?, notes) WHERE id = ?`
        )
          .bind(nextCode, nextStatus, body.expiresAt, body.notes ?? null, id)
          .run();
      } else if (body?.durationSeconds) {
        const nextExp = new Date(Date.now() + body.durationSeconds * 1000).toISOString();
        await env.DB.prepare(
          `UPDATE universal_codes SET code = ?, status = ?, duration_seconds = ?, expires_at = ?, notes = COALESCE(?, notes) WHERE id = ?`
        )
          .bind(nextCode, nextStatus, body.durationSeconds, nextExp, body.notes ?? null, id)
          .run();
      } else {
        await env.DB.prepare(
          `UPDATE universal_codes SET code = ?, status = ?, notes = COALESCE(?, notes) WHERE id = ?`
        )
          .bind(nextCode, nextStatus, body?.notes ?? null, id)
          .run();
      }

      if (nextStatus !== 'active') {
        const revIso = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE user_sessions SET revoked_at = ? WHERE universal_code_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, id)
          .run();
        await env.DB.prepare(
          `UPDATE subscription_tokens SET revoked_at = ? WHERE credential_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, id)
          .run();
      } else if (body?.expiresAt || body?.durationSeconds) {
        const uExp = await env.DB.prepare(`SELECT expires_at FROM universal_codes WHERE id = ?`)
          .bind(id)
          .first<{ expires_at: string }>();
        if (uExp) {
          await env.DB.prepare(
            `UPDATE subscription_tokens SET expires_at = ? WHERE credential_id = ? AND revoked_at IS NULL`
          )
            .bind(uExp.expires_at, id)
            .run();
        }
      }

      await writeSecurityLog(env.DB, {
        eventType:
          nextStatus === 'suspended' ? 'UNIVERSAL_CODE_SUSPENDED' : 'UNIVERSAL_CODE_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'universal_code',
        resourceId: id,
        result: 'success',
        details: `Updated universal code ${nextCode} (status: ${nextStatus})`,
        ipHash,
      });

      return respond({ ok: true });
    }

    if (uPatchMatch && request.method === 'DELETE') {
      const denied = requirePerm('universal.manage');
      if (denied) return denied;
      const id = uPatchMatch[1];
      await env.DB.prepare(`DELETE FROM universal_codes WHERE id = ?`).bind(id).run();
      await writeSecurityLog(env.DB, {
        eventType: 'UNIVERSAL_CODE_DELETED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'universal_code',
        resourceId: id,
        result: 'success',
        ipHash,
      });
      return respond({ ok: true });
    }

    const uHistoryMatch = pathname.match(/^\/api\/admin\/universal-codes\/([^/]+)\/history$/);
    if (uHistoryMatch && request.method === 'GET') {
      const denied = requirePerm('universal.view');
      if (denied) return denied;
      const rows = await env.DB.prepare(
        `SELECT * FROM subscription_access_records WHERE credential_id = ? ORDER BY created_at DESC LIMIT 30`
      )
        .bind(uHistoryMatch[1])
        .all();
      return respond({ history: rows.results });
    }

    // --- DEVICES MANAGEMENT ---
    if (pathname === '/api/admin/devices' && request.method === 'GET') {
      const denied = requirePerm('devices.view');
      if (denied) return denied;
      const rows = await env.DB.prepare(
        `SELECT rd.*, pk.id AS bound_key_id, pk.key_code AS bound_key_code
         FROM registered_devices rd
         LEFT JOIN product_keys pk ON pk.bound_device_id = rd.id
         ORDER BY rd.last_seen_at DESC`
      ).all();
      return respond({ devices: rows.results });
    }

    const devStatusMatch = pathname.match(/^\/api\/admin\/devices\/([^/]+)\/status$/);
    if (devStatusMatch && request.method === 'POST') {
      const denied = requirePerm('devices.unbind');
      if (denied) return denied;
      const deviceId = devStatusMatch[1];
      const body = await parseJsonBody<{ status?: 'trusted' | 'blocked' }>(request);
      if (!body?.status || !['trusted', 'blocked'].includes(body.status)) {
        return respond({ error: 'Invalid status' }, 400);
      }
      await env.DB.prepare(`UPDATE registered_devices SET status = ? WHERE id = ?`)
        .bind(body.status, deviceId)
        .run();
      if (body.status === 'blocked') {
        const revIso = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE user_sessions SET revoked_at = ? WHERE device_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, deviceId)
          .run();
        await env.DB.prepare(
          `UPDATE subscription_tokens SET revoked_at = ? WHERE device_id = ? AND revoked_at IS NULL`
        )
          .bind(revIso, deviceId)
          .run();
      }
      await writeSecurityLog(env.DB, {
        eventType: 'DEVICE_STATUS_CHANGED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'device',
        resourceId: deviceId,
        result: 'success',
        details: `Device set to ${body.status}`,
        ipHash,
      });
      return respond({ ok: true });
    }

    // --- ADMINISTRATOR MANAGEMENT (SUPER ADMIN ONLY) ---
    if (pathname === '/api/admin/admins' && request.method === 'GET') {
      const denied = requirePerm('admins.manage');
      if (denied) return denied;
      const admins = await env.DB.prepare(
        `SELECT id, username, email, role_id, custom_permissions_json, status, created_at, updated_at, last_login_at
         FROM administrators ORDER BY created_at ASC`
      ).all();
      const roles = await env.DB.prepare(`SELECT * FROM administrator_roles ORDER BY rank DESC`).all();
      const permissions = await env.DB.prepare(`SELECT * FROM permissions`).all();
      return respond({ admins: admins.results, roles: roles.results, permissions: permissions.results });
    }

    if (pathname === '/api/admin/admins' && request.method === 'POST') {
      const denied = requirePerm('admins.manage');
      if (denied) return denied;
      if (admin.roleId !== 'SUPER_ADMIN') {
        return respond({ error: 'Only SUPER ADMIN can create administrators.' }, 403);
      }

      const body = await parseJsonBody<{
        username?: string;
        email?: string;
        password?: string;
        roleId?: AdminRoleId;
        customPermissions?: string[];
      }>(request);

      const username = body?.username?.trim() ?? '';
      const email = body?.email?.trim().toLowerCase() ?? '';
      const password = body?.password ?? '';
      const roleId = body?.roleId ?? 'VIEW_ONLY';

      if (username.length < 3 || !email.includes('@') || password.length < 8) {
        return respond(
          { error: 'Username (min 3), valid email, and password (min 8 chars) required.' },
          400
        );
      }
      if (!VALID_ROLES.includes(roleId)) {
        return respond({ error: 'Invalid role' }, 400);
      }

      const { hashHex, saltHex } = await hashPassword(password);
      const id = randomId('adm');
      const nowIso = new Date().toISOString();
      const customPerms = (body?.customPermissions ?? []).filter(
        (p) => roleId === 'SUPER_ADMIN' || p !== 'admins.manage'
      );

      try {
        await env.DB.prepare(
          `INSERT INTO administrators (
            id, username, email, password_hash, password_salt, role_id, custom_permissions_json, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`
        )
          .bind(id, username, email, hashHex, saltHex, roleId, JSON.stringify(customPerms), nowIso, nowIso)
          .run();
      } catch {
        return respond({ error: 'Username or email already exists.' }, 409);
      }

      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_CREATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'administrator',
        resourceId: id,
        result: 'success',
        details: `Created ${username} with role ${roleId}`,
        ipHash,
      });

      return respond({ ok: true, id }, 201);
    }

    const adminPatchMatch = pathname.match(/^\/api\/admin\/admins\/([^/]+)$/);
    if (adminPatchMatch && request.method === 'PATCH') {
      const denied = requirePerm('admins.manage');
      if (denied) return denied;
      if (admin.roleId !== 'SUPER_ADMIN') {
        return respond({ error: 'Only SUPER ADMIN can modify administrators.' }, 403);
      }
      const targetId = adminPatchMatch[1];
      const body = await parseJsonBody<{
        roleId?: AdminRoleId;
        status?: 'active' | 'suspended';
        customPermissions?: string[];
        password?: string;
      }>(request);

      const target = await env.DB.prepare(`SELECT * FROM administrators WHERE id = ?`)
        .bind(targetId)
        .first<AdminRecord>();
      if (!target) return respond({ error: 'Administrator not found' }, 404);

      if (targetId === admin.id && (body?.status === 'suspended' || (body?.roleId && body.roleId !== 'SUPER_ADMIN'))) {
        return respond({ error: 'Cannot suspend or demote your own active SUPER ADMIN account.' }, 400);
      }

      const nextRole = body?.roleId && VALID_ROLES.includes(body.roleId) ? body.roleId : target.role_id;
      const nextStatus =
        body?.status && ['active', 'suspended'].includes(body.status) ? body.status : target.status;
      const nextPermsJson = body?.customPermissions
        ? JSON.stringify(
            body.customPermissions.filter((p) => nextRole === 'SUPER_ADMIN' || p !== 'admins.manage')
          )
        : target.custom_permissions_json;

      const nowIso = new Date().toISOString();
      if (body?.password && body.password.length >= 8) {
        const { hashHex, saltHex } = await hashPassword(body.password);
        await env.DB.prepare(
          `UPDATE administrators
           SET role_id = ?, status = ?, custom_permissions_json = ?, password_hash = ?, password_salt = ?, updated_at = ?
           WHERE id = ?`
        )
          .bind(nextRole, nextStatus, nextPermsJson, hashHex, saltHex, nowIso, targetId)
          .run();
      } else {
        await env.DB.prepare(
          `UPDATE administrators
           SET role_id = ?, status = ?, custom_permissions_json = ?, updated_at = ?
           WHERE id = ?`
        )
          .bind(nextRole, nextStatus, nextPermsJson, nowIso, targetId)
          .run();
      }

      if (nextStatus !== 'active') {
        await env.DB.prepare(
          `UPDATE admin_sessions SET revoked_at = ? WHERE admin_id = ? AND revoked_at IS NULL`
        )
          .bind(nowIso, targetId)
          .run();
      }

      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'administrator',
        resourceId: targetId,
        result: 'success',
        details: `Updated ${target.username}: role=${nextRole}, status=${nextStatus}`,
        ipHash,
      });

      return respond({ ok: true });
    }

    if (adminPatchMatch && request.method === 'DELETE') {
      const denied = requirePerm('admins.manage');
      if (denied) return denied;
      if (admin.roleId !== 'SUPER_ADMIN') {
        return respond({ error: 'Only SUPER ADMIN can delete administrators.' }, 403);
      }
      const targetId = adminPatchMatch[1];
      if (targetId === admin.id) {
        return respond({ error: 'Cannot delete your own SUPER ADMIN account.' }, 400);
      }
      await env.DB.prepare(`DELETE FROM administrators WHERE id = ?`).bind(targetId).run();
      await writeSecurityLog(env.DB, {
        eventType: 'ADMIN_DELETED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'administrator',
        resourceId: targetId,
        result: 'success',
        ipHash,
      });
      return respond({ ok: true });
    }

    // --- SERVERS (EXACTLY 5) ---
    if (pathname === '/api/admin/servers' && request.method === 'GET') {
      const denied = requirePerm('dashboard.view');
      if (denied) return denied;
      const rows = await env.DB.prepare(`SELECT * FROM servers ORDER BY sort_order ASC`).all();
      return respond({ servers: rows.results });
    }

    const serverPatchMatch = pathname.match(/^\/api\/admin\/servers\/([^/]+)$/);
    if (serverPatchMatch && request.method === 'PATCH') {
      const denied = requirePerm('servers.manage');
      if (denied) return denied;
      const serverId = serverPatchMatch[1] as ServerId;
      if (!VALID_SERVERS.includes(serverId)) return respond({ error: 'Invalid server' }, 404);

      const body = await parseJsonBody<{
        enabled?: boolean;
        status?: 'operational' | 'high_load' | 'maintenance';
        routingNote?: string;
        name?: string;
      }>(request);

      const existing = await env.DB.prepare(`SELECT * FROM servers WHERE id = ?`)
        .bind(serverId)
        .first<{ enabled: number; status: string; routing_note: string; name: string }>();
      if (!existing) return respond({ error: 'Server not found' }, 404);

      const enabled = body?.enabled === undefined ? existing.enabled : body.enabled ? 1 : 0;
      const status = body?.status ?? existing.status;
      const routingNote = body?.routingNote ?? existing.routing_note;
      const name = body?.name?.trim() || existing.name;

      await env.DB.prepare(
        `UPDATE servers SET enabled = ?, status = ?, routing_note = ?, name = ?, updated_at = ? WHERE id = ?`
      )
        .bind(enabled, status, routingNote, name, new Date().toISOString(), serverId)
        .run();

      await writeSecurityLog(env.DB, {
        eventType: 'SERVER_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'server',
        resourceId: serverId,
        result: 'success',
        details: `Server ${serverId}: enabled=${enabled}, status=${status}`,
        ipHash,
      });
      return respond({ ok: true });
    }

    // --- FEATURES (EXACTLY 2) ---
    if (pathname === '/api/admin/features' && request.method === 'GET') {
      const denied = requirePerm('dashboard.view');
      if (denied) return denied;
      const rows = await env.DB.prepare(`SELECT * FROM features`).all();
      return respond({ features: rows.results });
    }

    const featurePatchMatch = pathname.match(/^\/api\/admin\/features\/([^/]+)$/);
    if (featurePatchMatch && request.method === 'PATCH') {
      const denied = requirePerm('features.manage');
      if (denied) return denied;
      const featureId = featurePatchMatch[1] as FeatureId;
      if (!VALID_FEATURES.includes(featureId)) return respond({ error: 'Invalid feature' }, 404);

      const body = await parseJsonBody<{ enabled?: boolean; description?: string }>(request);
      const existing = await env.DB.prepare(`SELECT enabled, description FROM features WHERE id = ?`)
        .bind(featureId)
        .first<{ enabled: number; description: string }>();
      if (!existing) return respond({ error: 'Feature not found' }, 404);

      const enabled = body?.enabled === undefined ? existing.enabled : body.enabled ? 1 : 0;
      const description = body?.description ?? existing.description;

      await env.DB.prepare(
        `UPDATE features SET enabled = ?, description = ?, updated_at = ? WHERE id = ?`
      )
        .bind(enabled, description, new Date().toISOString(), featureId)
        .run();

      await writeSecurityLog(env.DB, {
        eventType: 'FEATURE_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'feature',
        resourceId: featureId,
        result: 'success',
        details: `Feature ${featureId} enabled=${enabled}`,
        ipHash,
      });
      return respond({ ok: true });
    }

    // --- SUBSCRIPTION URLS (EXACTLY 10) ---
    if (pathname === '/api/admin/subscription-urls' && request.method === 'GET') {
      const denied = requirePerm('urls.manage');
      if (denied) return denied;
      const rows = await env.DB.prepare(
        `SELECT su.*, s.name AS server_name, s.flag AS server_flag, f.title AS feature_title
         FROM subscription_urls su
         JOIN servers s ON s.id = su.server_id
         JOIN features f ON f.id = su.feature_id
         ORDER BY s.sort_order ASC, f.id ASC`
      ).all();
      return respond({ urls: rows.results });
    }

    const urlPatchMatch = pathname.match(/^\/api\/admin\/subscription-urls\/([^/]+)$/);
    if (urlPatchMatch && request.method === 'PATCH') {
      const denied = requirePerm('urls.manage');
      if (denied) return denied;
      const slotId = urlPatchMatch[1];
      const body = await parseJsonBody<{ url?: string; enabled?: boolean }>(request);

      const existing = await env.DB.prepare(`SELECT url, enabled FROM subscription_urls WHERE id = ?`)
        .bind(slotId)
        .first<{ url: string; enabled: number }>();
      if (!existing) return respond({ error: 'Subscription slot not found' }, 404);

      const nextUrl = body?.url !== undefined ? body.url.trim() : existing.url;
      if (nextUrl) {
        const safe = isSafeExternalUrl(nextUrl);
        if (!safe.ok) return respond({ error: safe.reason ?? 'Invalid URL' }, 400);
      }

      const nextEnabled =
        body?.enabled !== undefined ? (body.enabled && nextUrl ? 1 : 0) : existing.enabled;
      const nowIso = new Date().toISOString();

      await env.DB.prepare(
        `UPDATE subscription_urls SET url = ?, enabled = ?, updated_at = ?, updated_by_admin_id = ? WHERE id = ?`
      )
        .bind(nextUrl, nextEnabled, nowIso, admin.id, slotId)
        .run();

      await writeSecurityLog(env.DB, {
        eventType: 'SUBSCRIPTION_URL_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'subscription_url',
        resourceId: slotId,
        result: 'success',
        details: `Slot ${slotId} updated (enabled=${nextEnabled}, configured=${nextUrl.length > 0})`,
        ipHash,
      });

      return respond({ ok: true, enabled: nextEnabled === 1, updatedAt: nowIso });
    }

    const urlTestMatch = pathname.match(/^\/api\/admin\/subscription-urls\/([^/]+)\/test$/);
    if (urlTestMatch && request.method === 'POST') {
      const denied = requirePerm('urls.manage');
      if (denied) return denied;
      const slotId = urlTestMatch[1];
      const row = await env.DB.prepare(`SELECT url FROM subscription_urls WHERE id = ?`)
        .bind(slotId)
        .first<{ url: string }>();
      if (!row || !row.url.trim()) {
        return respond({ ok: false, status: 'Empty URL', message: 'Enter a URL before testing.' }, 400);
      }

      const check = isSafeExternalUrl(row.url);
      if (!check.ok) {
        return respond({ ok: false, status: 'Blocked', message: check.reason }, 400);
      }

      let testStatus = 'Unavailable';
      let ok = false;
      if (check.scheme === 'happ') {
        ok = true;
        testStatus = 'Valid happ:// URI format';
      } else {
        try {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 5000);
          const res = await fetch(row.url, { method: 'HEAD', signal: controller.signal });
          clearTimeout(timer);
          ok = res.ok;
          testStatus = `HTTP ${res.status}`;
        } catch (err) {
          testStatus = err instanceof Error ? err.message : 'Unreachable';
        }
      }

      const nowIso = new Date().toISOString();
      await env.DB.prepare(
        `UPDATE subscription_urls SET last_tested_at = ?, last_test_status = ? WHERE id = ?`
      )
        .bind(nowIso, testStatus, slotId)
        .run();

      return respond({ ok, status: testStatus, testedAt: nowIso });
    }

    // --- WEBSITE SETTINGS & MAINTENANCE MODE ---
    if (pathname === '/api/admin/settings' && request.method === 'GET') {
      const denied = requirePerm('dashboard.view');
      if (denied) return denied;
      const row = await env.DB.prepare(`SELECT * FROM website_settings WHERE id = 1`).first();
      return respond({ settings: row });
    }

    if (pathname === '/api/admin/settings' && request.method === 'PATCH') {
      const denied = requirePerm('settings.manage');
      if (denied) return denied;

      const body = await parseJsonBody<{
        websiteTitle?: string;
        maintenanceMode?: boolean;
        maintenanceMessage?: string;
        announcement?: string;
        allowAdminDuringMaintenance?: boolean;
        defaultServerId?: ServerId;
      }>(request);

      const existing = await env.DB.prepare(`SELECT * FROM website_settings WHERE id = 1`).first<{
        website_title: string;
        maintenance_mode: number;
        maintenance_message: string;
        announcement: string;
        allow_admin_during_maintenance: number;
        default_server_id: ServerId;
      }>();
      if (!existing) return respond({ error: 'Settings missing' }, 500);

      const nextTitle = body?.websiteTitle?.trim() || existing.website_title;
      const nextMaint =
        body?.maintenanceMode === undefined ? existing.maintenance_mode : body.maintenanceMode ? 1 : 0;
      const nextMaintMsg = body?.maintenanceMessage ?? existing.maintenance_message;
      const nextAnn = body?.announcement ?? existing.announcement;
      const nextAllowAdmin =
        body?.allowAdminDuringMaintenance === undefined
          ? existing.allow_admin_during_maintenance
          : body.allowAdminDuringMaintenance
          ? 1
          : 0;
      const nextDefaultServer =
        body?.defaultServerId && VALID_SERVERS.includes(body.defaultServerId)
          ? body.defaultServerId
          : existing.default_server_id;
      const nowIso = new Date().toISOString();

      await env.DB.prepare(
        `UPDATE website_settings
         SET website_title = ?, maintenance_mode = ?, maintenance_message = ?,
             announcement = ?, allow_admin_during_maintenance = ?, default_server_id = ?,
             updated_at = ?, updated_by = ?
         WHERE id = 1`
      )
        .bind(
          nextTitle,
          nextMaint,
          nextMaintMsg,
          nextAnn,
          nextAllowAdmin,
          nextDefaultServer,
          nowIso,
          admin.username
        )
        .run();

      await writeSecurityLog(env.DB, {
        eventType:
          nextMaint !== existing.maintenance_mode
            ? 'MAINTENANCE_MODE_CHANGED'
            : 'WEBSITE_SETTINGS_UPDATED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'website_settings',
        resourceId: '1',
        result: 'success',
        details: `maintenance=${nextMaint}, title=${nextTitle}`,
        ipHash,
      });

      return respond({ ok: true, updatedAt: nowIso, updatedBy: admin.username });
    }

    // --- BACKUP & RESTORE (SUPER ADMIN ONLY) ---
    if (pathname === '/api/admin/backup' && request.method === 'GET') {
      if (admin.roleId !== 'SUPER_ADMIN') {
        return respond({ error: 'Only SUPER ADMIN can export platform backups.' }, 403);
      }
      const [settingsRow, serversRes, featuresRes, urlsRes, keysRes, universalRes, devicesRes] =
        await Promise.all([
          env.DB.prepare(`SELECT * FROM website_settings WHERE id = 1`).first(),
          env.DB.prepare(`SELECT * FROM servers ORDER BY sort_order ASC`).all(),
          env.DB.prepare(`SELECT * FROM features`).all(),
          env.DB.prepare(`SELECT * FROM subscription_urls`).all(),
          env.DB.prepare(`SELECT * FROM product_keys`).all(),
          env.DB.prepare(`SELECT * FROM universal_codes`).all(),
          env.DB.prepare(`SELECT * FROM registered_devices`).all(),
        ]);

      await writeSecurityLog(env.DB, {
        eventType: 'BACKUP_EXPORTED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'database',
        resourceId: 'backup',
        result: 'success',
        details: `Exported ${keysRes.results.length} keys, ${universalRes.results.length} universal codes`,
        ipHash,
      });

      return respond({
        version: 1,
        exportedAt: new Date().toISOString(),
        settings: settingsRow,
        servers: serversRes.results,
        features: featuresRes.results,
        subscriptionUrls: urlsRes.results,
        productKeys: keysRes.results,
        universalCodes: universalRes.results,
        registeredDevices: devicesRes.results,
      });
    }

    if (pathname === '/api/admin/restore' && request.method === 'POST') {
      if (admin.roleId !== 'SUPER_ADMIN') {
        return respond({ error: 'Only SUPER ADMIN can restore platform backups.' }, 403);
      }

      const body = await parseJsonBody<{
        settings?: Record<string, any>;
        servers?: Record<string, any>[];
        features?: Record<string, any>[];
        subscriptionUrls?: Record<string, any>[];
        productKeys?: Record<string, any>[];
        universalCodes?: Record<string, any>[];
        registeredDevices?: Record<string, any>[];
      }>(request);

      if (!body || typeof body !== 'object') {
        return respond({ error: 'Invalid backup JSON payload.' }, 400);
      }

      if (body.settings) {
        const s = body.settings;
        await env.DB.prepare(
          `UPDATE website_settings
           SET website_title = ?, maintenance_mode = ?, maintenance_message = ?,
               announcement = ?, allow_admin_during_maintenance = ?, default_server_id = ?,
               updated_at = ?, updated_by = ?
           WHERE id = 1`
        )
          .bind(
            String(s.website_title ?? 'PRIME WIRE PRO'),
            Number(s.maintenance_mode ? 1 : 0),
            String(s.maintenance_message ?? ''),
            String(s.announcement ?? ''),
            Number(s.allow_admin_during_maintenance === 0 ? 0 : 1),
            VALID_SERVERS.includes(s.default_server_id) ? s.default_server_id : 'singapore',
            new Date().toISOString(),
            admin.username
          )
          .run();
      }

      if (Array.isArray(body.servers)) {
        for (const srv of body.servers) {
          if (!VALID_SERVERS.includes(srv.id)) continue;
          await env.DB.prepare(
            `UPDATE servers SET name = ?, enabled = ?, status = ?, routing_note = ?, updated_at = ? WHERE id = ?`
          )
            .bind(
              String(srv.name ?? srv.id),
              srv.enabled ? 1 : 0,
              ['operational', 'high_load', 'maintenance'].includes(srv.status)
                ? srv.status
                : 'operational',
              String(srv.routing_note ?? ''),
              new Date().toISOString(),
              srv.id
            )
            .run();
        }
      }

      if (Array.isArray(body.features)) {
        for (const feat of body.features) {
          if (!VALID_FEATURES.includes(feat.id)) continue;
          await env.DB.prepare(
            `UPDATE features SET description = ?, enabled = ?, updated_at = ? WHERE id = ?`
          )
            .bind(
              String(feat.description ?? ''),
              feat.enabled ? 1 : 0,
              new Date().toISOString(),
              feat.id
            )
            .run();
        }
      }

      if (Array.isArray(body.subscriptionUrls)) {
        for (const u of body.subscriptionUrls) {
          if (!VALID_SERVERS.includes(u.server_id) || !VALID_FEATURES.includes(u.feature_id)) continue;
          const nextUrl = String(u.url ?? '').trim();
          if (nextUrl && !isSafeExternalUrl(nextUrl).ok) continue;
          await env.DB.prepare(
            `UPDATE subscription_urls SET url = ?, enabled = ?, updated_at = ?, updated_by_admin_id = ?
             WHERE server_id = ? AND feature_id = ?`
          )
            .bind(
              nextUrl,
              u.enabled && nextUrl ? 1 : 0,
              new Date().toISOString(),
              admin.id,
              u.server_id,
              u.feature_id
            )
            .run();
        }
      }

      if (Array.isArray(body.registeredDevices)) {
        for (const d of body.registeredDevices) {
          if (!d.id || !d.device_token_hash) continue;
          await env.DB.prepare(
            `INSERT OR IGNORE INTO registered_devices (
              id, device_token_hash, device_label, platform, user_agent, status, first_seen_at, last_seen_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              String(d.id),
              String(d.device_token_hash),
              String(d.device_label ?? 'Device'),
              String(d.platform ?? 'Web'),
              String(d.user_agent ?? ''),
              d.status === 'blocked' ? 'blocked' : 'trusted',
              String(d.first_seen_at ?? new Date().toISOString()),
              String(d.last_seen_at ?? new Date().toISOString())
            )
            .run();
        }
      }

      if (Array.isArray(body.productKeys)) {
        for (const k of body.productKeys) {
          if (!k.id || !k.key_code) continue;
          await env.DB.prepare(
            `INSERT OR REPLACE INTO product_keys (
              id, key_code, status, duration_seconds, custom_expires_at,
              allowed_servers_json, allowed_features_json, bound_device_id, bound_at,
              created_by_admin_id, created_at, activated_at, expires_at, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              String(k.id),
              String(k.key_code),
              ['active', 'suspended', 'revoked', 'expired'].includes(k.status) ? k.status : 'active',
              Math.max(60, Number(k.duration_seconds ?? 86400)),
              k.custom_expires_at ?? null,
              String(k.allowed_servers_json ?? JSON.stringify(VALID_SERVERS)),
              String(k.allowed_features_json ?? JSON.stringify(VALID_FEATURES)),
              k.bound_device_id ?? null,
              k.bound_at ?? null,
              k.created_by_admin_id ?? admin.id,
              String(k.created_at ?? new Date().toISOString()),
              k.activated_at ?? null,
              k.expires_at ?? null,
              String(k.notes ?? '')
            )
            .run();
        }
      }

      if (Array.isArray(body.universalCodes)) {
        for (const uc of body.universalCodes) {
          if (!uc.id || !uc.code || !uc.expires_at) continue;
          await env.DB.prepare(
            `INSERT OR REPLACE INTO universal_codes (
              id, code, status, duration_seconds, custom_expires_at,
              allowed_servers_json, allowed_features_json, usage_count,
              created_by_admin_id, created_at, activated_at, expires_at, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              String(uc.id),
              String(uc.code),
              ['active', 'suspended', 'revoked', 'expired'].includes(uc.status) ? uc.status : 'active',
              Math.max(60, Number(uc.duration_seconds ?? 86400)),
              uc.custom_expires_at ?? null,
              String(uc.allowed_servers_json ?? JSON.stringify(VALID_SERVERS)),
              String(uc.allowed_features_json ?? JSON.stringify(VALID_FEATURES)),
              Number(uc.usage_count ?? 0),
              uc.created_by_admin_id ?? admin.id,
              String(uc.created_at ?? new Date().toISOString()),
              uc.activated_at ?? null,
              String(uc.expires_at),
              String(uc.notes ?? '')
            )
            .run();
        }
      }

      await writeSecurityLog(env.DB, {
        eventType: 'BACKUP_RESTORED',
        actorType: 'admin',
        actorId: admin.id,
        actorLabel: admin.username,
        resourceType: 'database',
        resourceId: 'restore',
        result: 'success',
        details: 'Restored settings, keys, universal codes, and URLs from backup',
        ipHash,
      });

      return respond({ ok: true });
    }

    // --- SECURITY LOGS (READ-ONLY APPEND-ONLY AUDIT LOG) ---
    if (pathname === '/api/admin/logs' && request.method === 'GET') {
      const denied = requirePerm('logs.view');
      if (denied) return denied;

      const resultFilter = url.searchParams.get('result');
      const search = url.searchParams.get('search')?.trim();
      let sql = `SELECT * FROM security_logs WHERE 1=1`;
      const binds: unknown[] = [];

      if (resultFilter && resultFilter !== 'all') {
        sql += ` AND result = ?`;
        binds.push(resultFilter);
      }
      if (search) {
        sql += ` AND (event_type LIKE ? OR actor_label LIKE ? OR details LIKE ?)`;
        binds.push(`%${search}%`, `%${search}%`, `%${search}%`);
      }
      sql += ` ORDER BY timestamp DESC LIMIT 200`;

      const rows = await env.DB.prepare(sql).bind(...binds).all();
      return respond({ logs: rows.results });
    }

    return respond({ error: 'Admin endpoint not found' }, 404);
  }

  return respond({ error: 'API route not found' }, 404);
}
