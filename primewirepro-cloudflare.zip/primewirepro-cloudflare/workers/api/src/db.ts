import { randomId, sha256Hex } from './crypto';
import { AdminRoleId, AuthenticatedAdmin, D1Database } from './types';

export interface SecurityLogInput {
  eventType: string;
  actorType: 'admin' | 'user' | 'system' | 'anonymous';
  actorId: string;
  actorLabel: string;
  resourceType: string;
  resourceId: string;
  result: 'success' | 'denied' | 'error';
  details?: string;
  ipHash?: string;
}

export async function writeSecurityLog(db: D1Database, input: SecurityLogInput): Promise<void> {
  try {
    await db
      .prepare(
        `INSERT INTO security_logs (
          id, event_type, timestamp, actor_type, actor_id, actor_label,
          resource_type, resource_id, result, details, ip_hash
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        randomId('log'),
        input.eventType,
        new Date().toISOString(),
        input.actorType,
        input.actorId,
        input.actorLabel,
        input.resourceType,
        input.resourceId,
        input.result,
        input.details ?? '',
        input.ipHash ?? ''
      )
      .run();
  } catch {
    // Audit log failure must not crash request handling
  }
}

export async function getClientIpHash(request: Request): Promise<string> {
  const ip =
    request.headers.get('CF-Connecting-IP') ??
    request.headers.get('X-Forwarded-For')?.split(',')[0]?.trim() ??
    '127.0.0.1';
  const digest = await sha256Hex(ip);
  return digest.slice(0, 16);
}

export async function checkRateLimit(
  db: D1Database,
  bucketKey: string,
  maxAttempts: number,
  windowMs: number,
  blockMs: number
): Promise<{ allowed: boolean; retryAfterSec: number }> {
  const now = Date.now();
  const row = await db
    .prepare(
      `SELECT attempts, window_start_ms, blocked_until_ms FROM rate_limits WHERE bucket_key = ?`
    )
    .bind(bucketKey)
    .first<{ attempts: number; window_start_ms: number; blocked_until_ms: number }>();

  if (!row) {
    await db
      .prepare(
        `INSERT INTO rate_limits (bucket_key, attempts, window_start_ms, blocked_until_ms)
         VALUES (?, 1, ?, 0)`
      )
      .bind(bucketKey, now)
      .run();
    return { allowed: true, retryAfterSec: 0 };
  }

  if (row.blocked_until_ms > now) {
    return {
      allowed: false,
      retryAfterSec: Math.ceil((row.blocked_until_ms - now) / 1000),
    };
  }

  if (now - row.window_start_ms > windowMs) {
    await db
      .prepare(
        `UPDATE rate_limits SET attempts = 1, window_start_ms = ?, blocked_until_ms = 0 WHERE bucket_key = ?`
      )
      .bind(now, bucketKey)
      .run();
    return { allowed: true, retryAfterSec: 0 };
  }

  const nextAttempts = row.attempts + 1;
  const blockedUntil = nextAttempts > maxAttempts ? now + blockMs : 0;

  await db
    .prepare(
      `UPDATE rate_limits SET attempts = ?, blocked_until_ms = ? WHERE bucket_key = ?`
    )
    .bind(nextAttempts, blockedUntil, bucketKey)
    .run();

  if (blockedUntil > 0) {
    return {
      allowed: false,
      retryAfterSec: Math.ceil(blockMs / 1000),
    };
  }

  return { allowed: true, retryAfterSec: 0 };
}

export async function resetRateLimit(db: D1Database, bucketKey: string): Promise<void> {
  await db.prepare(`DELETE FROM rate_limits WHERE bucket_key = ?`).bind(bucketKey).run();
}

export async function expireStaleCredentials(db: D1Database): Promise<void> {
  const nowIso = new Date().toISOString();

  // Expire active product keys whose expires_at has passed
  const expiredKeys = await db
    .prepare(
      `SELECT id, key_code FROM product_keys
       WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= ?`
    )
    .bind(nowIso)
    .all<{ id: string; key_code: string }>();

  if (expiredKeys.results.length > 0) {
    await db
      .prepare(
        `UPDATE product_keys SET status = 'expired'
         WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= ?`
      )
      .bind(nowIso)
      .run();

    for (const k of expiredKeys.results) {
      await writeSecurityLog(db, {
        eventType: 'KEY_EXPIRED',
        actorType: 'system',
        actorId: 'system',
        actorLabel: 'expiration-enforcer',
        resourceType: 'product_key',
        resourceId: k.id,
        result: 'success',
        details: `Product key ${k.key_code} expired automatically`,
      });
    }
  }

  // Expire active universal codes whose expires_at has passed
  const expiredUniversal = await db
    .prepare(
      `SELECT id, code FROM universal_codes
       WHERE status = 'active' AND expires_at <= ?`
    )
    .bind(nowIso)
    .all<{ id: string; code: string }>();

  if (expiredUniversal.results.length > 0) {
    await db
      .prepare(
        `UPDATE universal_codes SET status = 'expired'
         WHERE status = 'active' AND expires_at <= ?`
      )
      .bind(nowIso)
      .run();

    for (const u of expiredUniversal.results) {
      await writeSecurityLog(db, {
        eventType: 'UNIVERSAL_CODE_EXPIRED',
        actorType: 'system',
        actorId: 'system',
        actorLabel: 'expiration-enforcer',
        resourceType: 'universal_code',
        resourceId: u.id,
        result: 'success',
        details: `Universal code ${u.code} expired automatically`,
      });
    }
  }
}

export async function resolveAdminPermissions(
  db: D1Database,
  roleId: AdminRoleId,
  customPermissionsJson: string
): Promise<string[]> {
  const roleRows = await db
    .prepare(`SELECT permission_id FROM role_permissions WHERE role_id = ?`)
    .bind(roleId)
    .all<{ permission_id: string }>();

  const perms = new Set<string>(roleRows.results.map((r) => r.permission_id));
  try {
    const custom = JSON.parse(customPermissionsJson) as unknown;
    if (Array.isArray(custom)) {
      for (const p of custom) {
        if (typeof p === 'string' && (roleId === 'SUPER_ADMIN' || p !== 'admins.manage')) {
          perms.add(p);
        }
      }
    }
  } catch {
    // Ignore malformed JSON
  }
  return Array.from(perms);
}

export function hasPermission(admin: AuthenticatedAdmin, permission: string): boolean {
  return admin.roleId === 'SUPER_ADMIN' || admin.permissions.includes(permission);
}
