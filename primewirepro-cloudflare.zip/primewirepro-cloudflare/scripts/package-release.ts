import { execFileSync, execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const RELEASE_DIR = path.join(ROOT, 'release');
const STAGE_DIR = path.join(RELEASE_DIR, 'primewirepro-cloudflare');
const ZIP_PATH = path.join(RELEASE_DIR, 'primewirepro-cloudflare.zip');

function copyIfExists(relPath: string, destRelPath = relPath) {
  const src = path.join(ROOT, relPath);
  const dst = path.join(STAGE_DIR, destRelPath);
  if (!fs.existsSync(src)) {
    throw new Error(`Missing required file or directory: ${relPath}`);
  }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.cpSync(src, dst, {
    recursive: true,
    force: true,
    filter: (source) => {
      const base = path.basename(source);
      if (base === 'node_modules' || base === '.DS_Store') return false;
      return true;
    },
  });
}

function main() {
  console.log('1/4 Building public (dist/) and admin (dist-admin/) production bundles...');
  execSync('npm run build', { cwd: ROOT, stdio: 'inherit' });

  console.log('2/4 Preparing clean staging directory without secrets or local DB...');
  fs.rmSync(STAGE_DIR, { recursive: true, force: true });
  fs.rmSync(ZIP_PATH, { force: true });
  fs.mkdirSync(STAGE_DIR, { recursive: true });

  const requiredFiles = [
    '.env.example',
    '.gitignore',
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'vite.admin.config.ts',
    'index.html',
    'admin.html',
    'server.ts',
    'metadata.json',
    'CLOUDFLARE_DEPLOYMENT.md',
    'MOBILE_CLOUDFLARE_DEPLOYMENT_AR.md',
  ];
  for (const file of requiredFiles) {
    copyIfExists(file);
  }

  copyIfExists('src');
  copyIfExists('public');
  copyIfExists('workers');
  copyIfExists('scripts');
  copyIfExists('dist', 'prebuilt/public-pages');
  copyIfExists('dist-admin', 'prebuilt/admin-pages');

  const forbidden = ['.env', '.local-data'];
  for (const item of forbidden) {
    if (fs.existsSync(path.join(STAGE_DIR, item))) {
      throw new Error(`Security check failed: forbidden item "${item}" found in release stage!`);
    }
  }

  console.log('3/4 Creating ZIP archive with python3 zipfile...');
  const pyScript = [
    'import os, sys, zipfile',
    'stage_root, target_dir, zip_path = sys.argv[1], sys.argv[2], sys.argv[3]',
    'with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:',
    '    for root, dirs, files in os.walk(target_dir):',
    '        dirs.sort()',
    '        files.sort()',
    '        for f in files:',
    '            full_path = os.path.join(root, f)',
    '            arcname = os.path.relpath(full_path, stage_root)',
    '            zf.write(full_path, arcname)',
  ].join('\n');

  execFileSync('python3', ['-c', pyScript, RELEASE_DIR, STAGE_DIR, ZIP_PATH], {
    cwd: ROOT,
    stdio: 'inherit',
  });

  fs.rmSync(STAGE_DIR, { recursive: true, force: true });

  const stat = fs.statSync(ZIP_PATH);
  console.log(
    `4/4 Release package ready: ${ZIP_PATH} (${(stat.size / 1024).toFixed(1)} KB)`
  );
}

main();
